-- Create a test table
create table public.test_connection (
    id uuid default gen_random_uuid() primary key,
    message text not null,
    created_at timestamptz default now(),
    status boolean default true
);

-- Enable RLS (Row Level Security)
alter table public.test_connection enable row level security;

-- Create a policy to allow all authenticated users to read
create policy "Allow authenticated users to read test_connection"
    on public.test_connection
    for select
    to authenticated
    using (true);

-- Create a policy to allow authenticated users to insert
create policy "Allow authenticated users to insert test_connection"
    on public.test_connection
    for insert
    to authenticated
    with check (true);

-- Insert some test data
insert into public.test_connection (message) values ('Test connection successful!');
