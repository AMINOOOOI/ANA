-- Drop existing policies if they exist
drop policy if exists "Anyone can read notes" on public.test_notes;
drop policy if exists "Authenticated users can create notes" on public.test_notes;
drop policy if exists "Users can update own notes" on public.test_notes;
drop policy if exists "Users can delete own notes" on public.test_notes;

-- Create simpler policies for testing
create policy "Enable read access for all users" on public.test_notes
    for select using (true);

create policy "Enable insert access for all users" on public.test_notes
    for insert with check (true);

create policy "Enable update access for all users" on public.test_notes
    for update using (true);

create policy "Enable delete access for all users" on public.test_notes
    for delete using (true);

-- Alter the table to remove the created_by constraint temporarily for testing
alter table public.test_notes alter column created_by drop not null;
