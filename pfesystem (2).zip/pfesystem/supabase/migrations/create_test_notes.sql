-- Create a test notes table
create table public.test_notes (
    id uuid default gen_random_uuid() primary key,
    title text not null,
    content text,
    created_at timestamptz default now(),
    created_by uuid references auth.users(id)
);

-- Enable Row Level Security (RLS)
alter table public.test_notes enable row level security;

-- Create policy for reading notes (anyone can read)
create policy "Anyone can read notes" on public.test_notes
    for select using (true);

-- Create policy for inserting notes (authenticated users only)
create policy "Authenticated users can create notes" on public.test_notes
    for insert
    with check (auth.role() = 'authenticated');

-- Create policy for updating own notes
create policy "Users can update own notes" on public.test_notes
    for update using (auth.uid() = created_by);

-- Create policy for deleting own notes
create policy "Users can delete own notes" on public.test_notes
    for delete using (auth.uid() = created_by);

-- Insert some test data
insert into public.test_notes (title, content) 
values 
    ('Test Note 1', 'This is a test note to verify the connection'),
    ('Test Note 2', 'Another test note');
