import { useEffect, useState } from 'react';
import { supabase } from '../utils/supabase';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions
} from '@mui/material';
import { Delete, Edit } from '@mui/icons-material';

const SupabaseTest = () => {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newNote, setNewNote] = useState({ title: '', content: '' });
  const [editingNote, setEditingNote] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('Testing connection...');

  // Fetch all notes
  const fetchNotes = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('test_notes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setNotes(data);
      setConnectionStatus('Connection successful! ✅');
    } catch (err) {
      setError('Error fetching notes: ' + err.message);
      setConnectionStatus('Connection failed! ❌');
    } finally {
      setLoading(false);
    }
  };
  // Add new note
  const addNote = async (e) => {
    e.preventDefault();
    if (!newNote.title.trim()) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('test_notes')
        .insert([
          {
            title: newNote.title,
            content: newNote.content
          }
        ])
        .select();

      if (error) throw error;

      await fetchNotes(); // Refresh the notes list
      setNewNote({ title: '', content: '' });
    } catch (err) {
      setError('Error adding note: ' + err.message);
    } finally {
      setLoading(false);
    }
  };
  // Update note
  const updateNote = async () => {
    if (!editingNote) return;

    try {
      setLoading(true);
      const { error } = await supabase
        .from('test_notes')
        .update({
          title: editingNote.title,
          content: editingNote.content
        })
        .eq('id', editingNote.id);

      if (error) throw error;

      await fetchNotes(); // Refresh the notes list
      setEditingNote(null);
      setOpenDialog(false);
    } catch (err) {
      setError('Error updating note: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Delete note
  const deleteNote = async (id) => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('test_notes')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await fetchNotes(); // Refresh the notes list
    } catch (err) {
      setError('Error deleting note: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Test connection on component mount
  useEffect(() => {
    fetchNotes();
  }, []);

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 3 }}>
          <Typography variant="h4" gutterBottom>
            Supabase Connection Test
          </Typography>

          <Alert 
            severity={connectionStatus.includes('successful') ? "success" : "info"} 
            sx={{ mb: 3 }}
          >
            {connectionStatus}
          </Alert>

          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          <Box component="form" onSubmit={addNote} sx={{ mb: 4 }}>
            <TextField
              fullWidth
              label="Note Title"
              value={newNote.title}
              onChange={(e) => setNewNote({ ...newNote, title: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Note Content"
              value={newNote.content}
              onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
              margin="normal"
              multiline
              rows={3}
            />
            <Button
              type="submit"
              variant="contained"
              sx={{ mt: 2 }}
              disabled={loading}
            >
              Add Note
            </Button>
          </Box>

          {loading ? (
            <Box display="flex" justifyContent="center">
              <CircularProgress />
            </Box>
          ) : (
            <List>
              {notes.map((note) => (
                <ListItem
                  key={note.id}
                  sx={{
                    border: 1,
                    borderColor: 'grey.200',
                    borderRadius: 1,
                    mb: 1
                  }}
                >
                  <ListItemText
                    primary={note.title}
                    secondary={note.content}
                  />
                  <ListItemSecondaryAction>
                    <IconButton
                      edge="end"
                      aria-label="edit"
                      onClick={() => {
                        setEditingNote(note);
                        setOpenDialog(true);
                      }}
                      sx={{ mr: 1 }}
                    >
                      <Edit />
                    </IconButton>
                    <IconButton
                      edge="end"
                      aria-label="delete"
                      onClick={() => deleteNote(note.id)}
                    >
                      <Delete />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
              ))}
            </List>
          )}
        </Paper>
      </Box>

      {/* Edit Dialog */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Edit Note</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Title"
            value={editingNote?.title || ''}
            onChange={(e) => setEditingNote({ ...editingNote, title: e.target.value })}
            margin="normal"
          />
          <TextField
            fullWidth
            label="Content"
            value={editingNote?.content || ''}
            onChange={(e) => setEditingNote({ ...editingNote, content: e.target.value })}
            margin="normal"
            multiline
            rows={3}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button onClick={updateNote} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default SupabaseTest;
