import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Container, 
  Paper, 
  Typography, 
  TextField, 
  Button, 
  Box,
  Alert,
  IconButton,
  InputAdornment,
  Stack
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useAuth } from '../../contexts/AuthContext';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !password) {
      return setError('Veuillez remplir tous les champs');
    }
    
    try {
      setError('');
      setLoading(true);
      await login(email, password);
      navigate('/dashboard');
    } catch (error) {
      setError('Email ou mot de passe invalide');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container component="main" maxWidth="sm" sx={{ 
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center'
    }}>
      <Paper 
        elevation={3} 
        sx={{ 
          p: 4, 
          borderRadius: 2,
          background: 'white',
        }}
      >
        {/* Logo and Title */}
        <Box sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center',
          mb: 4
        }}>
          <Box
            component="div"
            sx={{
              width: 80,
              height: 80,
              borderRadius: '50%',
              backgroundColor: '#2196f3',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mb: 2
            }}
          >
            <Box
              component="img"
              src="/graduation-cap.png"
              alt="Logo"
              sx={{
                width: 40,
                height: 40,
                filter: 'brightness(0) invert(1)'
              }}
            />
          </Box>
          <Typography variant="h4" component="h1" sx={{ color: '#2196f3', mb: 1 }}>
            Gestion des PFE
          </Typography>
          <Typography variant="subtitle1" sx={{ color: '#666' }}>
            Système de gestion des projets de fin d'études
          </Typography>
        </Box>

        <Typography variant="h5" component="h2" sx={{ mb: 3, textAlign: 'center' }}>
          Connexion
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 3 }}>
            {error}
          </Alert>
        )}

        <Box component="form" onSubmit={handleSubmit} noValidate>
          <TextField
            margin="normal"
            required
            fullWidth
            label="Email"
            name="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            sx={{ mb: 2 }}
          />

          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Mot de passe"
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
            sx={{ mb: 3 }}
          />

          <Stack spacing={2}>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              disabled={loading}
              sx={{
                py: 1.5,
                textTransform: 'none',
                fontSize: '1rem',
                bgcolor: '#2196f3',
                '&:hover': {
                  bgcolor: '#1976d2'
                }
              }}
            >
              Se connecter
            </Button>

            <Button
              component={Link}
              to="/register"
              fullWidth
              variant="outlined"
              sx={{
                py: 1.5,
                textTransform: 'none',
                fontSize: '1rem',
                borderColor: '#2196f3',
                color: '#2196f3',
                '&:hover': {
                  borderColor: '#1976d2',
                  bgcolor: 'rgba(33, 150, 243, 0.04)'
                }
              }}
            >
              S'inscrire
            </Button>
          </Stack>
        </Box>
      </Paper>

      <Typography 
        variant="body2" 
        color="text.secondary" 
        align="center" 
        sx={{ mt: 3 }}
      >
        © {new Date().getFullYear()} Système de gestion des PFE
      </Typography>
    </Container>
  );
};

export default Login;
