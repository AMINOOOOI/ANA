import React, { useEffect, useState } from 'react';
import { supabase } from '../utils/supabase';
import { 
  Container, 
  Paper, 
  Typography, 
  Button, 
  Box,
  Alert,
  CircularProgress
} from '@mui/material';

const TestConnection = () => {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Function to fetch test message
  const fetchTestMessage = async () => {
    try {
      setLoading(true);
      setError('');

      const { data, error } = await supabase
        .from('test_connection')
        .select('message')
        .single();

      if (error) throw error;

      setMessage(data.message);
    } catch (err) {
      setError('Error connecting to Supabase: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Function to add a new test message
  const addNewMessage = async () => {
    try {
      setLoading(true);
      setError('');

      const { error } = await supabase
        .from('test_connection')
        .insert([
          { message: 'New test message added at ' + new Date().toLocaleString() }
        ]);

      if (error) throw error;

      // Refresh the messages
      fetchTestMessage();
    } catch (err) {
      setError('Error adding message: ' + err.message);
      setLoading(false);
    }
  };

  // Fetch message when component mounts
  useEffect(() => {
    fetchTestMessage();
  }, []);

  return (
    <Container maxWidth="sm">
      <Box sx={{ mt: 4 }}>
        <Paper sx={{ p: 3 }}>
          <Typography variant="h5" gutterBottom>
            Supabase Connection Test
          </Typography>

          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          {loading ? (
            <Box display="flex" justifyContent="center" my={3}>
              <CircularProgress />
            </Box>
          ) : (
            <Box>
              <Alert severity="info" sx={{ mb: 2 }}>
                {message || 'No message found'}
              </Alert>

              <Button 
                variant="contained" 
                onClick={addNewMessage}
                sx={{ mr: 2 }}
              >
                Add New Test Message
              </Button>

              <Button 
                variant="outlined" 
                onClick={fetchTestMessage}
              >
                Refresh Message
              </Button>
            </Box>
          )}
        </Paper>
      </Box>
    </Container>
  );
};

export default TestConnection;
