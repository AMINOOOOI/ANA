import { useState, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, CssBaseline } from '@mui/material';
import './App.css';

// Auth Components
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import SupabaseTest from './components/SupabaseTest';

// Layout Components
import Layout from './components/layout/Layout';

// Page Components
import Dashboard from './pages/Dashboard';
import PfeSubmission from './pages/PfeSubmission';
import PfeList from './pages/PfeList';
import PfeDetail from './pages/PfeDetail';
import PfeEdit from './pages/PfeEdit';
import UserManagement from './pages/UserManagement';
import Statistics from './pages/Statistics';
import Profile from './pages/Profile';
import NotFound from './pages/NotFound';

// Context
import { AuthProvider, useAuth } from './contexts/AuthContext';

// Création des thèmes pour chaque rôle utilisateur avec des couleurs plus claires
const createAdminTheme = () => createTheme({
  palette: {
    mode: 'light',
    primary: {
      // Bleu clair professionnel
      main: '#64b5f6', // Light blue 300
      light: '#9be7ff',
      dark: '#2286c3',
      contrastText: '#ffffff',
    },
    secondary: {
      // Turquoise clair
      main: '#4dd0e1', // Cyan 300
      light: '#88ffff',
      dark: '#009faf',
      contrastText: '#ffffff',
    },
    background: {
      default: '#f5f7fa', // Fond légèrement plus bleuté
      paper: '#ffffff',
    },
    error: {
      main: '#d32f2f',
      light: '#ef5350',
      dark: '#b71c1c',
    },
    warning: {
      main: '#ed6c02',
      light: '#ff9800',
      dark: '#e65100',
    },
    info: {
      main: '#0288d1',
      light: '#03a9f4',
      dark: '#01579b',
    },
    success: {
      main: '#2e7d32',
      light: '#4caf50',
      dark: '#1b5e20',
    },
    grey: {
      50: '#fafafa',
      100: '#f5f5f5',
      200: '#eeeeee',
      300: '#e0e0e0',
      400: '#bdbdbd',
      500: '#9e9e9e',
      600: '#757575',
      700: '#616161',
      800: '#424242',
      900: '#212121',
    },
    divider: 'rgba(0, 0, 0, 0.08)',
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 700,
      fontSize: '2.5rem',
      lineHeight: 1.2,
      letterSpacing: '-0.01em',
    },
    h2: {
      fontWeight: 600,
      fontSize: '2rem',
      lineHeight: 1.3,
      letterSpacing: '-0.005em',
    },
    h3: {
      fontWeight: 600,
      fontSize: '1.75rem',
      lineHeight: 1.3,
    },
    h4: {
      fontWeight: 600,
      fontSize: '1.5rem',
      lineHeight: 1.35,
    },
    h5: {
      fontWeight: 600,
      fontSize: '1.25rem',
      lineHeight: 1.4,
    },
    h6: {
      fontWeight: 600,
      fontSize: '1rem',
      lineHeight: 1.4,
    },
    subtitle1: {
      fontSize: '1rem',
      fontWeight: 500,
      lineHeight: 1.5,
    },
    subtitle2: {
      fontSize: '0.875rem',
      fontWeight: 500,
      lineHeight: 1.5,
    },
    body1: {
      fontSize: '1rem',
      lineHeight: 1.5,
    },
    body2: {
      fontSize: '0.875rem',
      lineHeight: 1.5,
    },
    button: {
      textTransform: 'none',
      fontWeight: 600,
    },
    caption: {
      fontSize: '0.75rem',
      lineHeight: 1.5,
      fontWeight: 400,
    },
  },
  shape: {
    borderRadius: 10, // Coins plus arrondis pour un look plus moderne
  },
  shadows: [
    'none',
    '0px 2px 4px rgba(0, 0, 0, 0.05)',
    '0px 4px 8px rgba(0, 0, 0, 0.06)',
    '0px 6px 12px rgba(0, 0, 0, 0.07)',
    '0px 8px 16px rgba(0, 0, 0, 0.08)',
    '0px 10px 20px rgba(0, 0, 0, 0.09)',
    '0px 12px 24px rgba(0, 0, 0, 0.10)',
    '0px 14px 28px rgba(0, 0, 0, 0.11)',
    '0px 16px 32px rgba(0, 0, 0, 0.12)',
    '0px 18px 36px rgba(0, 0, 0, 0.13)',
    '0px 20px 40px rgba(0, 0, 0, 0.14)',
    '0px 22px 44px rgba(0, 0, 0, 0.15)',
    '0px 24px 48px rgba(0, 0, 0, 0.16)',
    '0px 26px 52px rgba(0, 0, 0, 0.17)',
    '0px 28px 56px rgba(0, 0, 0, 0.18)',
    '0px 30px 60px rgba(0, 0, 0, 0.19)',
    '0px 32px 64px rgba(0, 0, 0, 0.20)',
    '0px 34px 68px rgba(0, 0, 0, 0.21)',
    '0px 36px 72px rgba(0, 0, 0, 0.22)',
    '0px 38px 76px rgba(0, 0, 0, 0.23)',
    '0px 40px 80px rgba(0, 0, 0, 0.24)',
    '0px 42px 84px rgba(0, 0, 0, 0.25)',
    '0px 44px 88px rgba(0, 0, 0, 0.26)',
    '0px 46px 92px rgba(0, 0, 0, 0.27)',
    '0px 48px 96px rgba(0, 0, 0, 0.28)',
  ],
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        '*': {
          boxSizing: 'border-box',
        },
        body: {
          margin: 0,
          transition: 'background-color 0.2s ease',
        },
        a: {
          textDecoration: 'none',
          color: 'inherit',
        },
      },
    },
    MuiContainer: {
      styleOverrides: {
        root: {
          paddingLeft: '24px',
          paddingRight: '24px',
          '@media (min-width: 600px)': {
            paddingLeft: '32px',
            paddingRight: '32px',
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 600,
          borderRadius: 10,
          padding: '10px 20px',
          boxShadow: 'none',
          transition: 'all 0.2s ease',
          '&:hover': {
            transform: 'translateY(-2px)',
            boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)',
          },
        },
        contained: {
          boxShadow: '0px 3px 6px rgba(0, 0, 0, 0.08)',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0px 3px 6px rgba(0, 0, 0, 0.06)',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        rounded: {
          borderRadius: 12,
        },
        elevation1: {
          boxShadow: '0px 3px 6px rgba(0, 0, 0, 0.06)',
        },
      },
    },
  },
});

// Création du thème pour les bibliothécaires avec des couleurs plus claires
const createLibraryTheme = () => createTheme({
  palette: {
    mode: 'light',
    primary: {
      // Violet clair et doux
      main: '#b39ddb', // Deep purple 200
      light: '#e6ceff',
      dark: '#836fa9',
      contrastText: '#ffffff',
    },
    secondary: {
      // Pêche chaleureux
      main: '#ffab91', // Deep orange 200
      light: '#ffddc1',
      dark: '#c97b63',
      contrastText: '#ffffff',
    },
    background: {
      default: '#faf8fa', // Fond légèrement violet très pâle
      paper: '#ffffff',
    },
    error: {
      main: '#d32f2f',
    },
    info: {
      main: '#0288d1',
    },
    success: {
      main: '#2e7d32',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 600,
    },
    h2: {
      fontWeight: 600,
    },
    h3: {
      fontWeight: 600,
    },
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
    subtitle1: {
      fontSize: '1rem',
    },
    subtitle2: {
      fontWeight: 500,
    },
    button: {
      textTransform: 'none',
      fontWeight: 600,
    },
  },
  shape: {
    borderRadius: 8,
  },
  shadows: [
    'none',
    '0px 2px 4px rgba(0, 0, 0, 0.05)',
    '0px 4px 8px rgba(0, 0, 0, 0.06)',
    '0px 6px 12px rgba(0, 0, 0, 0.07)',
    '0px 8px 16px rgba(0, 0, 0, 0.08)',
    '0px 10px 20px rgba(0, 0, 0, 0.09)',
    '0px 12px 24px rgba(0, 0, 0, 0.10)',
    '0px 14px 28px rgba(0, 0, 0, 0.11)',
    '0px 16px 32px rgba(0, 0, 0, 0.12)',
    '0px 18px 36px rgba(0, 0, 0, 0.13)',
    '0px 20px 40px rgba(0, 0, 0, 0.14)',
    '0px 22px 44px rgba(0, 0, 0, 0.15)',
    '0px 24px 48px rgba(0, 0, 0, 0.16)',
    '0px 26px 52px rgba(0, 0, 0, 0.17)',
    '0px 28px 56px rgba(0, 0, 0, 0.18)',
    '0px 30px 60px rgba(0, 0, 0, 0.19)',
    '0px 32px 64px rgba(0, 0, 0, 0.20)',
    '0px 34px 68px rgba(0, 0, 0, 0.21)',
    '0px 36px 72px rgba(0, 0, 0, 0.22)',
    '0px 38px 76px rgba(0, 0, 0, 0.23)',
    '0px 40px 80px rgba(0, 0, 0, 0.24)',
  ],
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          boxShadow: '0px 3px 8px rgba(0, 0, 0, 0.1)',
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          boxShadow: 'none',
          '&:hover': {
            boxShadow: '0px 3px 8px rgba(0, 0, 0, 0.1)',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.05)',
          '&:hover': {
            boxShadow: '0px 6px 16px rgba(0, 0, 0, 0.1)',
          },
          transition: 'all 0.3s ease',
        },
      },
    },
  },
});

// Création du thème pour les étudiants avec des couleurs plus claires
const createStudentTheme = () => createTheme({
  palette: {
    mode: 'light',
    primary: {
      // Vert menthe frais et léger
      main: '#81c784', // Green 300
      light: '#b2fab4',
      dark: '#519657',
      contrastText: '#ffffff',
    },
    secondary: {
      // Bleu ciel clair, plus jeune et dynamique
      main: '#80deea', // Cyan 200
      light: '#b4ffff',
      dark: '#4bacb8',
      contrastText: '#ffffff',
    },
    background: {
      default: '#f0f8f1', // Fond légèrement verdâtre très pâle
      paper: '#ffffff',
    },
    error: {
      main: '#d32f2f',
    },
    info: {
      main: '#0288d1',
    },
    success: {
      main: '#2e7d32',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontWeight: 600,
    },
    h2: {
      fontWeight: 600,
    },
    h3: {
      fontWeight: 600,
    },
    h4: {
      fontWeight: 600,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
    subtitle1: {
      fontSize: '1rem',
    },
    subtitle2: {
      fontWeight: 500,
    },
    button: {
      textTransform: 'none',
      fontWeight: 600,
    },
  },
  shape: {
    borderRadius: 16,
  },
  shadows: [
    'none',
    '0px 2px 4px rgba(0, 0, 0, 0.05)',
    '0px 4px 8px rgba(0, 0, 0, 0.06)',
    '0px 6px 12px rgba(0, 0, 0, 0.07)',
    '0px 8px 16px rgba(0, 0, 0, 0.08)',
    '0px 10px 20px rgba(0, 0, 0, 0.09)',
    '0px 12px 24px rgba(0, 0, 0, 0.10)',
    '0px 14px 28px rgba(0, 0, 0, 0.11)',
    '0px 16px 32px rgba(0, 0, 0, 0.12)',
    '0px 18px 36px rgba(0, 0, 0, 0.13)',
    '0px 20px 40px rgba(0, 0, 0, 0.14)',
    '0px 22px 44px rgba(0, 0, 0, 0.15)',
    '0px 24px 48px rgba(0, 0, 0, 0.16)',
    '0px 26px 52px rgba(0, 0, 0, 0.17)',
    '0px 28px 56px rgba(0, 0, 0, 0.18)',
    '0px 30px 60px rgba(0, 0, 0, 0.19)',
    '0px 32px 64px rgba(0, 0, 0, 0.20)',
    '0px 34px 68px rgba(0, 0, 0, 0.21)',
    '0px 36px 72px rgba(0, 0, 0, 0.22)',
    '0px 38px 76px rgba(0, 0, 0, 0.23)',
    '0px 40px 80px rgba(0, 0, 0, 0.24)',
  ],
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          boxShadow: '0px 3px 8px rgba(0, 0, 0, 0.1)',
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: 'none',
          '&:hover': {
            boxShadow: '0px 3px 8px rgba(0, 0, 0, 0.1)',
            transform: 'translateY(-2px)',
          },
          transition: 'all 0.2s ease',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.05)',
          '&:hover': {
            boxShadow: '0px 6px 16px rgba(0, 0, 0, 0.1)',
            transform: 'translateY(-3px)',
          },
          transition: 'all 0.3s ease',
        },
      },
    },
  },
});

// Composant wrapper pour appliquer le thème après avoir accédé au contexte d'authentification
const ThemeWrapper = ({ children }) => {
  const { userRole } = useAuth();
  
  // Générer le thème en fonction du rôle utilisateur
  const theme = useMemo(() => {
    if (userRole === 'admin') {
      return createAdminTheme();
    } else if (userRole === 'library') {
      return createLibraryTheme();
    } else if (userRole === 'student') {
      return createStudentTheme();
    } else {
      // Thème par défaut pour les utilisateurs non connectés (login page)
      return createAdminTheme();
    }
  }, [userRole]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      {children}
    </ThemeProvider>
  );
};

function App() {
  // Protected route component
  const ProtectedRoute = ({ children, allowedRoles = [] }) => {
    const { currentUser, userRole } = useAuth();
    
    if (!currentUser) {
      return <Navigate to="/login" replace />;
    }
    
    if (allowedRoles.length > 0 && !allowedRoles.includes(userRole)) {
      return <Navigate to="/dashboard" replace />;
    }
    
    return children;
  };

  return (
    <AuthProvider>
      <ThemeWrapper>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/test-supabase" element={<SupabaseTest />} />
            
            {/* Protected routes */}
            <Route path="/" element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<Dashboard />} />
              
              <Route path="pfe">
                <Route index element={<PfeList />} />
                <Route path="new" element={<PfeSubmission />} />
                <Route path=":id" element={<PfeDetail />} />
                <Route path=":id/edit" element={<PfeEdit />} />
              </Route>
              
              <Route path="users" element={
                <ProtectedRoute allowedRoles={['admin']}>
                  <UserManagement />
                </ProtectedRoute>
              } />
              
              <Route path="statistics" element={
                <ProtectedRoute allowedRoles={['admin']}>
                  <Statistics />
                </ProtectedRoute>
              } />
              
              <Route path="profile" element={<Profile />} />
              
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Router>
      </ThemeWrapper>
    </AuthProvider>
  );
}

export default App;
