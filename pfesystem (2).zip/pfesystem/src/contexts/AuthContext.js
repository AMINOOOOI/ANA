import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [loading, setLoading] = useState(true);

  // Function to log in user
  const login = async (email, password) => {
    try {
      // This would normally be an API call to authenticate
      // For demo purposes, we're simulating different user roles
      let user = null;
      let role = null;
      
      if (email === 'admin@example.com' && password === 'admin123') {
        user = { id: 1, email, name: 'Admin User' };
        role = 'admin';
      } else if (email === 'library@example.com' && password === 'library123') {
        user = { id: 2, email, name: 'Library Manager' };
        role = 'library';
      } else if (email === 'student@example.com' && password === 'student123') {
        user = { id: 3, email, name: 'Student User' };
        role = 'student';
      } else {
        throw new Error('Invalid email or password');
      }
      
      setCurrentUser(user);
      setUserRole(role);
      localStorage.setItem('user', JSON.stringify(user));
      localStorage.setItem('userRole', role);
      
      return { user, role };
    } catch (error) {
      throw error;
    }
  };

  // Function to log out user
  const logout = () => {
    setCurrentUser(null);
    setUserRole(null);
    localStorage.removeItem('user');
    localStorage.removeItem('userRole');
  };

  // Function to register new user (would be expanded in a real app)
  const register = async (email, password, name, role = 'student') => {
    try {
      // This would normally be an API call to register
      const user = { id: Date.now(), email, name };
      setCurrentUser(user);
      setUserRole(role);
      localStorage.setItem('user', JSON.stringify(user));
      localStorage.setItem('userRole', role);
      return { user, role };
    } catch (error) {
      throw error;
    }
  };

  // Check if user is logged in on mount
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    const role = localStorage.getItem('userRole');
    
    if (user && role) {
      setCurrentUser(user);
      setUserRole(role);
    }
    
    setLoading(false);
  }, []);

  const value = {
    currentUser,
    userRole,
    login,
    logout,
    register,
    isAdmin: userRole === 'admin',
    isLibrarian: userRole === 'library',
    isStudent: userRole === 'student',
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
