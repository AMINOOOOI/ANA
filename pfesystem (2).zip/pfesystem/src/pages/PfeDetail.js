import React, { useState, useEffect } from 'react';
import {
  Container, Typography, Box, Paper, Grid, Chip, Button,
  Card, CardContent, Divider, Avatar, Stack, List, ListItem, ListItemText, ListItemIcon
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import {
  CalendarMonth as CalendarIcon,
  School as SchoolIcon,
  Person as PersonIcon,
  Apartment as DepartmentIcon,
  MenuBook as FormationIcon,
  Badge as MasarIcon,
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Description as DocumentIcon,
  Download as DownloadIcon
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

// Données réalistes pour les PFEs avec formations spécifiques
const mockPFEs = [
  {
    id: 1,
    title: 'Système intelligent d\'optimisation des ressources dans les centres de données',
    description: 'Développement d\'un algorithme d\'intelligence artificielle pour prédire et optimiser la consommation énergétique des data centers.',
    student: 'Ahmed Alami, Fatima Bennani',
    studentEmail: 'ahmed.alami@example.com',
    studentIds: ['18421962', '18456789'], // Codes MASAR
    supervisor: 'Dr. Mohammed Tazi',
    supervisorEmail: 'mohammed.tazi@example.com',
    department: 'Informatique',
    formation: 'Master Artificial Intelligence & Digital Computing',
    educationLevel: 'Bac+5',
    submitDate: '2025-05-01',
    defenseDate: '2025-07-15', // Date de soutenance
    domain: 'Intelligence Artificielle',
    keywords: ['Deep Learning', 'Optimisation énergétique', 'Centres de données', 'Python', 'TensorFlow'],
    abstract: 'Ce projet propose une solution d\'IA pour prédire et optimiser la consommation énergétique dans les centres de données, réduisant ainsi l\'empreinte carbone tout en maintenant la performance.',
    report: { name: 'Rapport_PFE_AI_DataCenter.pdf', size: '2.4 MB', date: '2025-06-15' }
  },
  {
    id: 2,
    title: 'Conception d\'un système embarqué pour véhicules électriques autonomes',
    description: 'Développement d\'un système de contrôle embarqué pour la gestion optimale de la batterie et de la navigation des véhicules électriques autonomes.',
    student: 'Youssef El Kaddioui',
    studentEmail: 'youssef.kaddioui@example.com',
    studentIds: ['19523871'], // Codes MASAR
    supervisor: 'Dr. Laila Bensouda',
    supervisorEmail: 'laila.bensouda@example.com',
    department: 'Génie Électrique',
    formation: 'Génie Électrique – Systèmes Embarqués & Informatique Industrielle',
    educationLevel: 'Bac+5',
    submitDate: '2025-05-03',
    defenseDate: '2025-06-30', // Date de soutenance
    domain: 'Systèmes Embarqués',
    keywords: ['IoT', 'Automobile', 'Microcontrôleurs', 'C++', 'Temps réel'],
    abstract: 'Ce projet développe un système embarqué innovant pour optimiser l\'autonomie et la sécurité des véhicules électriques autonomes en conditions réelles.',
    report: { name: 'Rapport_Systeme_Embarque_VE.pdf', size: '1.8 MB', date: '2025-06-01' }
  },
  {
    id: 3,
    title: 'Conception et développement d\'une cellule de production robotisée',
    description: 'Intégration de bras robotiques collaboratifs dans une chaîne de production industrielle avec monitoring en temps réel.',
    student: 'Karim El Mansouri, Hassan Tadlaoui',
    studentEmail: 'karim.mansouri@example.com',
    studentIds: ['20125478', '20136589'], // Codes MASAR
    supervisor: 'Dr. Noureddine El Ouafi',
    supervisorEmail: 'noureddine.ouafi@example.com',
    department: 'Génie Mécanique',
    formation: 'Cycle ingénieur Productique / Mécatronique',
    educationLevel: 'Bac+5',
    submitDate: '2025-04-25',
    defenseDate: '2025-07-10', // Date de soutenance
    domain: 'Mécatronique',
    keywords: ['Robotique industrielle', 'Industrie 4.0', 'Automation', 'Manufacturing', 'IoT'],
    abstract: 'Ce projet développe une cellule robotisée intégrant des cobots de dernière génération pour améliorer la flexibilité et la productivité dans la production industrielle.',
    report: { name: 'Rapport_PFE_Robotique_Industrielle.pdf', size: '3.1 MB', date: '2025-06-20' }
  },
  {
    id: 4,
    title: 'Caractérisation des propriétés électriques des matériaux supraconducteurs',
    description: 'Étude expérimentale et théorique des propriétés physiques des matériaux supraconducteurs à haute température.',
    student: 'Salma Benamour',
    studentEmail: 'salma.benamour@example.com',
    studentIds: ['19745621'], // Codes MASAR
    supervisor: 'Dr. Latifa Zekri',
    supervisorEmail: 'latifa.zekri@example.com',
    department: 'Physique',
    formation: 'Master Ingénierie des Matériaux',
    educationLevel: 'Bac+5',
    submitDate: '2025-05-10',
    defenseDate: '2025-07-05', // Date de soutenance
    domain: 'Matériaux',
    keywords: ['Supraconductivité', 'Matériaux avancés', 'Caracatérisation', 'Modélisation', 'Thermodynamique'],
    abstract: 'Ce projet explore les propriétés électriques et magnétiques des nouveaux matériaux supraconducteurs pour des applications en électronique et en production d\'énergie.',
    report: { name: 'Rapport_PFE_Materiaux_Supra.pdf', size: '2.7 MB', date: '2025-06-10' }
  },
  {
    id: 5,
    title: 'Développement d\'algorithmes de bioinformatique pour l\'analyse du microbiome intestinal',
    description: 'Conception d\'outils d\'analyse bio-informatique pour l\'étude des relations entre microbiome intestinal et maladies auto-immunes.',
    student: 'Meryem Alaoui',
    studentEmail: 'meryem.alaoui@example.com',
    studentIds: ['20184632'], // Codes MASAR
    supervisor: 'Dr. Hafida Merzouki',
    supervisorEmail: 'hafida.merzouki@example.com',
    department: 'Sciences de la Vie',
    formation: 'Master Sciences & Techniques en Neurosciences & Biotechnologie',
    educationLevel: 'Bac+5',
    submitDate: '2025-05-12',
    defenseDate: '2025-07-20', // Date de soutenance
    domain: 'Biotechnologie',
    keywords: ['Bio-informatique', 'Microbiome', 'Séquençage haut débit', 'Machine Learning', 'Santé'],
    abstract: 'Ce projet développe des algorithmes d\'analyse pour détecter les relations entre la composition du microbiome intestinal et l\'apparition de maladies auto-immunes.',
    report: { name: 'Rapport_PFE_Bioinformatique_Microbiome.pdf', size: '2.9 MB', date: '2025-06-25' }
  },
];

const PfeDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { userRole } = useAuth();
  const [pfe, setPfe] = useState(null);
  const [loading, setLoading] = useState(true);

  // Simuler le chargement des données
  useEffect(() => {
    // Simuler un délai de chargement
    const timer = setTimeout(() => {
      const foundPfe = mockPFEs.find(p => p.id === parseInt(id));
      setPfe(foundPfe || null);
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [id]);

  // Fonction supprimée (Statut des PFE)  

  // Si le PFE n'est pas trouvé
  if (!loading && !pfe) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
          <Typography variant="h5" color="text.secondary" gutterBottom>
            Projet non trouvé
          </Typography>
          <Typography variant="body1" sx={{ mb: 3 }}>
            Le projet de fin d'études avec l'ID {id} n'existe pas ou a été supprimé.
          </Typography>
          <Button 
            variant="contained" 
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate('/pfe')}
          >
            Retour à la liste
          </Button>
        </Paper>
      </Container>
    );
  }

  // Écran de chargement
  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 4, borderRadius: 2 }}>
          <Typography variant="h6" sx={{ opacity: 0.7 }}>
            Chargement des détails du PFE...
          </Typography>
        </Paper>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* En-tête avec bouton retour */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <Button 
          variant="outlined" 
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/pfe')}
          sx={{ mr: 2 }}
        >
          Retour
        </Button>
        <Box>
          <Typography variant="h4" component="h1" fontWeight="bold">
            Détails du PFE
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            ID: {pfe.id}
          </Typography>
        </Box>
      </Box>

      <Grid container spacing={3}>
        {/* Titre du PFE */}
        <Grid item xs={12}>
          <Paper 
            elevation={0} 
            sx={{ 
              p: 3, 
              borderRadius: 3, 
              background: 'linear-gradient(135deg, #0277bd 0%, #26c6da 100%)', 
              color: 'white',
              position: 'relative',
              overflow: 'hidden'
            }}
          >
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '120px',
                height: '120px',
                borderRadius: '50%',
                background: 'rgba(255, 255, 255, 0.1)',
                transform: 'translate(30%, -30%)',
              }}
            />
            <Box sx={{ position: 'relative', zIndex: 1 }}>
              <Typography variant="h5" fontWeight="bold" gutterBottom>
                {pfe.title}
              </Typography>
            </Box>
          </Paper>
        </Grid>

        {/* Informations principales */}
        <Grid item xs={12} md={6}>
          <Card sx={{ borderRadius: 2, height: '100%' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Informations académiques
              </Typography>
              
              <Stack spacing={2}>
                {/* Département */}
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <DepartmentIcon sx={{ mr: 1, color: 'primary.main' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Département
                    </Typography>
                    <Typography variant="body1">
                      {pfe.department}
                    </Typography>
                  </Box>
                </Box>
                
                {/* Formation */}
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <FormationIcon sx={{ mr: 1, color: 'primary.main' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Formation
                    </Typography>
                    <Typography variant="body1">
                      {pfe.formation}
                    </Typography>
                  </Box>
                </Box>
                
                {/* Niveau d'étude */}
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <SchoolIcon sx={{ mr: 1, color: 'primary.main' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Niveau d'étude
                    </Typography>
                    <Typography variant="body1">
                      {pfe.educationLevel}
                    </Typography>
                  </Box>
                </Box>
                
                {/* Date de soutenance */}
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <CalendarIcon sx={{ mr: 1, color: 'primary.main' }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">
                      Date de soutenance
                    </Typography>
                    <Typography variant="body1" fontWeight="medium">
                      {new Date(pfe.defenseDate).toLocaleDateString()}
                    </Typography>
                  </Box>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* Étudiants et encadrant */}
        <Grid item xs={12} md={6}>
          <Card sx={{ borderRadius: 2, height: '100%' }}>
            <CardContent>
              {/* Étudiants */}
              <Typography variant="h6" gutterBottom>
                Étudiants
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Avatar sx={{ bgcolor: '#26a69a', mr: 2 }}>
                  <PersonIcon />
                </Avatar>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="body1" fontWeight="medium">
                    {pfe.student}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Code{pfe.studentIds.length > 1 ? 's' : ''} MASAR: {pfe.studentIds.join(', ')}
                  </Typography>
                </Box>
              </Box>

              <Divider sx={{ my: 2 }} />
              
              {/* Encadrants */}
              <Typography variant="h6" gutterBottom>
                Encadrant
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Avatar sx={{ bgcolor: '#7b1fa2', mr: 2 }}>
                  <PersonIcon />
                </Avatar>
                <Box>
                  <Typography variant="body1" fontWeight="medium">
                    {pfe.supervisor}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {pfe.supervisorEmail}
                  </Typography>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        {/* Section Rapport PDF */}
        <Grid item xs={12}>
          <Card sx={{ borderRadius: 2, mt: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                <DocumentIcon sx={{ mr: 1, color: 'primary.main' }} />
                Rapport PFE
              </Typography>
              
              {pfe.report ? (
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', bgcolor: '#f5f5f5', p: 2, borderRadius: 1 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <DocumentIcon color="primary" sx={{ fontSize: 40, mr: 2 }} />
                    <Box>
                      <Typography variant="body1" fontWeight="medium">{pfe.report.name}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {pfe.report.size} • Ajouté le {new Date(pfe.report.date).toLocaleDateString()}
                      </Typography>
                    </Box>
                  </Box>
                  <Button 
                    variant="contained" 
                    color="primary"
                    startIcon={<DownloadIcon />}
                  >
                    Télécharger le rapport
                  </Button>
                </Box>
              ) : (
                <Typography variant="body2" color="text.secondary" sx={{ mt: 2, fontStyle: 'italic' }}>
                  Aucun rapport PDF disponible pour ce PFE.
                </Typography>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Actions */}
      {(userRole === 'admin' || userRole === 'library') && (
        <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end' }}>
          <Button 
            variant="contained" 
            color="primary"
            startIcon={<EditIcon />}
            onClick={() => navigate(`/pfe/${id}/edit`)}
          >
            Modifier ce PFE
          </Button>
        </Box>
      )}
    </Container>
  );
};

export default PfeDetail;
