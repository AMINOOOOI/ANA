import React, { useEffect, useState } from 'react';
import { Container, Typography, Box, Button, Paper, Grid, useTheme, alpha } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { Home as HomeIcon, ArrowBack as ArrowBackIcon, SentimentDissatisfied as SadIcon } from '@mui/icons-material';
import { keyframes } from '@emotion/react';

// Définition des animations
const float = keyframes`
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-20px); }
`;

const pulse = keyframes`
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.8; transform: scale(1.05); }
`;

const rotate = keyframes`
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
`;

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
`;

const NotFound = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  // Effet de parallaxe au mouvement de la souris
  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);
  
  return (
    <Box
      sx={{
        display: 'flex',
        minHeight: '100vh',
        background: 'radial-gradient(circle at 50% 50%, #f6f6f8 0%, #eef1f5 100%)',
        overflow: 'hidden',
        p: { xs: 2, md: 4 }
      }}
    >
      <Paper
        elevation={0}
        sx={{
          flex: 1,
          display: 'flex',
          flexDirection: { xs: 'column', md: 'row' },
          overflow: 'hidden',
          borderRadius: 4,
          boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
          m: { xs: 0, md: 2 },
          maxWidth: { md: '1200px' },
          mx: 'auto'
        }}
      >
        {/* Côté gauche - décoratif */}
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            position: 'relative',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            p: { xs: 4, md: 6 },
            background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.primary.main} 60%, ${theme.palette.secondary.dark} 100%)`,
            color: 'white',
            overflow: 'hidden',
          }}
        >
          {/* Particules décoratives animées */}
          {[...Array(12)].map((_, i) => (
            <Box
              key={i}
              sx={{
                position: 'absolute',
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 40 + 20}px`,
                height: `${Math.random() * 40 + 20}px`,
                borderRadius: '50%',
                background: alpha('#fff', 0.1),
                animation: `${pulse} ${Math.random() * 4 + 3}s infinite`,
                animationDelay: `${Math.random() * 2}s`,
                transform: `translate(${(mousePosition.x / window.innerWidth - 0.5) * 20}px, ${(mousePosition.y / window.innerHeight - 0.5) * 20}px)`,
                transition: 'transform 0.3s ease-out',
              }}
            />
          ))}

          {/* 404 Texte principal */}
          <Typography 
            variant="h1" 
            component="h1" 
            sx={{ 
              fontSize: { xs: '7rem', sm: '10rem', md: '14rem' }, 
              fontWeight: 900,
              letterSpacing: '-8px',
              mb: 2,
              textShadow: '4px 6px 10px rgba(0,0,0,0.4)',
              position: 'relative',
              zIndex: 2,
              animation: `${float} 6s ease-in-out infinite`,
              background: 'linear-gradient(to bottom, #ffffff, #e0e0e0)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}
          >
            404
          </Typography>

          {/* Icône triste animée */}
          <Box 
            sx={{ 
              animation: `${pulse} 2s infinite`,
              mb: 4,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <SadIcon sx={{ fontSize: 50, opacity: 0.9 }} />
          </Box>

          <Typography 
            variant="h5" 
            component="div" 
            align="center"
            sx={{ 
              fontWeight: 300,
              mb: 4,
              maxWidth: '80%',
              textShadow: '0 2px 4px rgba(0,0,0,0.2)',
              animation: `${fadeIn} 1s ease-out`,
              opacity: 0.9,
            }}
          >
            La page que vous recherchez n'existe pas ou a été déplacée
          </Typography>

          {/* Cercle décoratif rotatif */}
          <Box
            sx={{
              position: 'absolute',
              bottom: '-50px',
              right: '-50px',
              width: '200px',
              height: '200px',
              borderRadius: '50%',
              border: '15px solid rgba(255,255,255,0.1)',
              animation: `${rotate} 25s linear infinite`,
            }}
          />
        </Grid>

        {/* Côté droit - contenu */}
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            p: { xs: 4, md: 6 },
            bgcolor: 'white',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          {/* Forme décorative avec animation */}
          <Box
            sx={{
              position: 'absolute',
              top: '5%',
              right: '5%',
              width: '100px',
              height: '100px',
              background: alpha(theme.palette.primary.light, 0.1),
              borderRadius: '30% 70% 70% 30% / 30% 30% 70% 70%',
              animation: `${pulse} 8s infinite`,
            }}
          />
          
          <Typography 
            variant="h3" 
            component="h2" 
            align="center"
            gutterBottom
            sx={{
              fontWeight: '800',
              mb: 3,
              background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              animation: `${fadeIn} 0.6s ease-out`,
            }}
          >
            Oups ! Page non trouvée
          </Typography>

          <Typography 
            variant="body1" 
            align="center"
            color="text.secondary"
            sx={{ 
              mb: 5,
              maxWidth: '450px',
              lineHeight: 1.8,
              animation: `${fadeIn} 0.8s ease-out`,
            }}
          >
            La page que vous essayez d'atteindre n'est plus disponible ou n'a jamais existé. Retournez au tableau de bord ou à la page précédente pour continuer votre navigation.
          </Typography>

          <Box 
            sx={{ 
              display: 'flex', 
              flexDirection: { xs: 'column', sm: 'row' }, 
              gap: 2,
              animation: `${fadeIn} 1s ease-out`,
            }}
          >
            <Button
              variant="contained"
              color="primary"
              size="large"
              startIcon={<HomeIcon />}
              onClick={() => navigate('/dashboard')}
              sx={{ 
                px: 4, 
                py: 1.5,
                borderRadius: '12px',
                fontWeight: 600,
                boxShadow: '0 8px 16px rgba(0, 0, 0, 0.1)',
                transition: 'transform 0.2s, box-shadow 0.2s',
                '&:hover': {
                  transform: 'translateY(-3px)',
                  boxShadow: '0 12px 20px rgba(0, 0, 0, 0.15)',
                }
              }}
            >
              Tableau de bord
            </Button>

            <Button
              variant="outlined"
              size="large"
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate(-1)}
              sx={{ 
                px: 4, 
                py: 1.5,
                borderRadius: '12px',
                borderWidth: 2,
                fontWeight: 600,
                transition: 'transform 0.2s',
                '&:hover': {
                  borderWidth: 2,
                  transform: 'translateY(-3px)',
                }
              }}
            >
              Retour
            </Button>
          </Box>

          <Typography 
            variant="subtitle2" 
            color="text.secondary" 
            align="center" 
            sx={{ 
              mt: 8,
              animation: `${fadeIn} 1.2s ease-out`,
              fontSize: '0.9rem',
              opacity: 0.7,
            }}
          >
            Si vous pensez qu'il s'agit d'une erreur, contactez votre administrateur système.
          </Typography>
          
          {/* Forme décorative avec animation */}
          <Box
            sx={{
              position: 'absolute',
              bottom: '5%',
              left: '10%',
              width: '80px',
              height: '80px',
              background: alpha(theme.palette.secondary.light, 0.1),
              borderRadius: '60% 40% 30% 70% / 60% 30% 70% 40%',
              animation: `${pulse} 10s infinite`,
              animationDelay: '2s',
            }}
          />
        </Grid>
      </Paper>
    </Box>
  );
};

export default NotFound;
