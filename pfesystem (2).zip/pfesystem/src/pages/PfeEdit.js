import React, { useState, useEffect } from 'react';
import {
  Container, Typography, Box, Paper, Grid, TextField, Button,
  FormControl, InputLabel, MenuItem, Select, Stack, Divider,
  CircularProgress, Snackbar, Alert
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  Save as SaveIcon,
  ArrowBack as ArrowBackIcon,
} from '@mui/icons-material';

// Données fictives pour les PFEs - même que dans PfeDetail.js
const mockPFEs = [
  {
    id: 1,
    title: 'Système de gestion de projets de fin d\'études',
    description: 'Conception et développement d\'une application web pour faciliter la gestion des projets de fin d\'études.',
    student: 'Ahmed Alami, Fatima Bennani',
    studentEmail: 'ahmed.alami@example.com',
    studentIds: ['18421962', '18456789'], // Codes MASAR
    supervisor: 'Dr. Mohammed Tazi',
    supervisorEmail: 'mohammed.tazi@example.com',
    department: 'Informatique',
    formation: 'Master',
    educationLevel: 'Bac+5',
    submitDate: '2025-05-01',
    defenseDate: '2025-07-15', // Date de soutenance
    domain: 'Web Development',
    keywords: ['React', 'Node.js', 'Material UI', 'MongoDB', 'Express'],
    abstract: 'Ce projet vise à développer une plateforme intégrée pour la gestion des PFEs.',
    report: { name: 'Rapport_PFE_System_Gestion.pdf', size: '2.4 MB', date: '2025-06-15' }
  },
  {
    id: 2,
    title: 'Application mobile de suivi médical',
    description: 'Développement d\'une application mobile permettant aux patients de suivre leurs paramètres de santé.',
    student: 'Youssef El Kaddioui',
    studentEmail: 'youssef.kaddioui@example.com',
    studentIds: ['19523871'], // Codes MASAR
    supervisor: 'Dr. Laila Bensouda',
    supervisorEmail: 'laila.bensouda@example.com',
    department: 'Génie Logiciel',
    formation: 'Licence',
    educationLevel: 'Bac+3',
    submitDate: '2025-04-15',
    defenseDate: '2025-06-30', // Date de soutenance
    domain: 'Mobile Development',
    keywords: ['Flutter', 'Firebase', 'Health Tech'],
    abstract: 'Application permettant le suivi des paramètres de santé et la communication patient-médecin.',
    report: { name: 'Rapport_App_Mobile_Medical.pdf', size: '1.8 MB', date: '2025-06-10' }
  }
];

// Options pour les champs de sélection
const departmentOptions = ['Informatique', 'Génie Logiciel', 'Génie Civil', 'Électronique', 'Mécanique'];
const formationOptions = ['Licence', 'Master', 'Doctorat'];
const educationLevelOptions = ['Bac+3', 'Bac+5', 'Bac+8'];

const PfeEdit = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { userRole } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success'
  });

  // État pour stocker les données du formulaire
  const [formData, setFormData] = useState({
    title: '',
    department: '',
    formation: '',
    educationLevel: '',
    student: '',
    studentIds: [],
    supervisor: '',
    supervisorEmail: '',
    defenseDate: ''
  });

  // Simuler le chargement des données
  useEffect(() => {
    // Vérifier les autorisations
    if (userRole !== 'admin' && userRole !== 'library') {
      navigate('/dashboard');
      return;
    }

    // Simuler un délai de chargement
    const timer = setTimeout(() => {
      const foundPfe = mockPFEs.find(p => p.id === parseInt(id));
      
      if (foundPfe) {
        // Mettre à jour le formulaire avec les données du PFE
        setFormData({
          title: foundPfe.title,
          department: foundPfe.department,
          formation: foundPfe.formation,
          educationLevel: foundPfe.educationLevel,
          student: foundPfe.student,
          studentIds: foundPfe.studentIds.join(', '),
          supervisor: foundPfe.supervisor,
          supervisorEmail: foundPfe.supervisorEmail,
          defenseDate: foundPfe.defenseDate
        });
      }
      
      setLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, [id, userRole, navigate]);

  // Gérer les changements dans le formulaire
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Gérer la soumission du formulaire
  const handleSubmit = (e) => {
    e.preventDefault();
    setSaving(true);

    // Simuler la sauvegarde
    setTimeout(() => {
      setSaving(false);
      setSnackbar({
        open: true,
        message: 'PFE modifié avec succès',
        severity: 'success'
      });

      // Redirection vers la page de détail après quelques secondes
      setTimeout(() => {
        navigate(`/pfe/${id}`);
      }, 1500);
    }, 1000);
  };

  // Fermer le snackbar
  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({
      ...prev,
      open: false
    }));
  };

  // Si le PFE n'est pas trouvé
  if (!loading && !formData.title) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 4, textAlign: 'center', borderRadius: 2 }}>
          <Typography variant="h5" color="text.secondary" gutterBottom>
            Projet non trouvé
          </Typography>
          <Typography variant="body1" sx={{ mb: 3 }}>
            Le projet de fin d'études avec l'ID {id} n'existe pas ou a été supprimé.
          </Typography>
          <Button 
            variant="contained" 
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate('/pfe')}
          >
            Retour à la liste
          </Button>
        </Paper>
      </Container>
    );
  }

  // Écran de chargement
  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper sx={{ p: 4, borderRadius: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', py: 6 }}>
            <CircularProgress />
            <Typography variant="h6" sx={{ ml: 2, opacity: 0.7 }}>
              Chargement des données du PFE...
            </Typography>
          </Box>
        </Paper>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* En-tête avec bouton retour */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <Button 
          variant="outlined" 
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate(`/pfe/${id}`)}
          sx={{ mr: 2 }}
        >
          Annuler
        </Button>
        <Box>
          <Typography variant="h4" component="h1" fontWeight="bold">
            Modifier le PFE
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            ID: {id}
          </Typography>
        </Box>
      </Box>

      {/* Formulaire de modification */}
      <Paper 
        elevation={2} 
        sx={{ 
          p: 4, 
          borderRadius: 2,
          background: 'linear-gradient(to right bottom, rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 1))',
          backdropFilter: 'blur(10px)'
        }}
      >
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            {/* Titre du PFE */}
            <Grid item xs={12}>
              <TextField
                name="title"
                label="Titre du PFE"
                value={formData.title}
                onChange={handleChange}
                fullWidth
                required
                variant="outlined"
              />
            </Grid>

            {/* Département, formation et niveau d'études */}
            <Grid item xs={12} md={4}>
              <FormControl fullWidth required>
                <InputLabel>Département</InputLabel>
                <Select
                  name="department"
                  value={formData.department}
                  onChange={handleChange}
                  label="Département"
                >
                  {departmentOptions.map(option => (
                    <MenuItem key={option} value={option}>{option}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth required>
                <InputLabel>Formation</InputLabel>
                <Select
                  name="formation"
                  value={formData.formation}
                  onChange={handleChange}
                  label="Formation"
                >
                  {formationOptions.map(option => (
                    <MenuItem key={option} value={option}>{option}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12} md={4}>
              <FormControl fullWidth required>
                <InputLabel>Niveau d'études</InputLabel>
                <Select
                  name="educationLevel"
                  value={formData.educationLevel}
                  onChange={handleChange}
                  label="Niveau d'études"
                >
                  {educationLevelOptions.map(option => (
                    <MenuItem key={option} value={option}>{option}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>

            <Grid item xs={12}>
              <Divider sx={{ my: 1 }} />
            </Grid>

            {/* Étudiants */}
            <Grid item xs={12} md={6}>
              <TextField
                name="student"
                label="Noms des étudiants"
                value={formData.student}
                onChange={handleChange}
                fullWidth
                required
                variant="outlined"
                helperText="Séparez les noms par une virgule si plusieurs étudiants"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="studentIds"
                label="Codes MASAR"
                value={formData.studentIds}
                onChange={handleChange}
                fullWidth
                required
                variant="outlined"
                helperText="Séparez les codes MASAR par une virgule si plusieurs étudiants"
              />
            </Grid>

            <Grid item xs={12}>
              <Divider sx={{ my: 1 }} />
            </Grid>

            {/* Encadrant */}
            <Grid item xs={12} md={6}>
              <TextField
                name="supervisor"
                label="Nom de l'encadrant"
                value={formData.supervisor}
                onChange={handleChange}
                fullWidth
                required
                variant="outlined"
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                name="supervisorEmail"
                label="Email de l'encadrant"
                value={formData.supervisorEmail}
                onChange={handleChange}
                fullWidth
                type="email"
                variant="outlined"
              />
            </Grid>

            <Grid item xs={12}>
              <Divider sx={{ my: 1 }} />
            </Grid>

            {/* Date de soutenance */}
            <Grid item xs={12} md={6}>
              <TextField
                name="defenseDate"
                label="Date de soutenance"
                type="date"
                value={formData.defenseDate}
                onChange={handleChange}
                InputLabelProps={{
                  shrink: true,
                }}
                fullWidth
                required
                variant="outlined"
              />
            </Grid>

            {/* Boutons d'action */}
            <Grid item xs={12}>
              <Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mt: 2 }}>
                <Button
                  variant="outlined"
                  color="inherit"
                  onClick={() => navigate(`/pfe/${id}`)}
                >
                  Annuler
                </Button>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  startIcon={saving ? <CircularProgress size={20} color="inherit" /> : <SaveIcon />}
                  disabled={saving}
                >
                  {saving ? 'Enregistrement...' : 'Enregistrer les modifications'}
                </Button>
              </Stack>
            </Grid>
          </Grid>
        </form>
      </Paper>

      {/* Snackbar de notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default PfeEdit;
