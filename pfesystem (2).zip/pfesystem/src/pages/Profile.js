import React from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  Avatar,
  Card,
  CardContent,
  Chip,
  Button
} from '@mui/material';
import {
  Email as EmailIcon,
  Dashboard as DashboardIcon,
  Settings as SettingsIcon
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

// Données simplifiées pour chaque profil
const profileData = {
  admin: {
    email: 'admin@universite.ma',
    accessLevel: 'Droits complets'
  },
  library: {
    email: 'bibliotheque@universite.ma',
    accessLevel: 'Gestion des PFEs'
  },
  student: {
    email: 'etudiant@universite.ma',
    accessLevel: 'Consultation uniquement'
  }
};

const Profile = () => {
  const { userRole, currentUser } = useAuth();
  
  // Récupérer les données du profil selon le rôle
  const userData = profileData[userRole] || {};
  
  return (
    <Container maxWidth="sm" sx={{ mt: 4, mb: 4 }}>
      {/* Titre de la page */}
      <Typography variant="h4" component="h1" fontWeight="bold" gutterBottom>
        Mon Profil
      </Typography>
      <Typography variant="subtitle1" color="text.secondary" sx={{ mb: 4 }}>
        Informations de compte
      </Typography>
      
      {/* Carte de profil simplifiée */}
      <Card elevation={2} sx={{ borderRadius: 3, overflow: 'visible', position: 'relative' }}>
        <Box 
          sx={{ 
            height: 100, 
            bgcolor: 'primary.light', 
            borderTopLeftRadius: 12, 
            borderTopRightRadius: 12 
          }}
        />
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mt: -6, mb: 3, px: 3 }}>
          <Avatar 
            alt={currentUser?.name || 'User'} 
            src="/static/images/avatar/1.jpg"
            sx={{ 
              width: 100, 
              height: 100, 
              border: '4px solid white',
              boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
            }} 
          />
          <Typography variant="h5" sx={{ mt: 2, fontWeight: 'bold' }}>
            {currentUser?.name || 'Utilisateur'}
          </Typography>
          
          <Chip 
            label={userRole === 'admin' ? 'Administrateur' : userRole === 'library' ? 'Bibliothécaire' : 'Étudiant'} 
            color="primary" 
            sx={{ 
              mt: 1,
              px: 1,
              textTransform: 'uppercase',
              fontWeight: 'bold',
              fontSize: '0.75rem'
            }} 
          />
          
          {/* Informations essentielles */}
          <Box sx={{ width: '100%', mt: 4, mb: 2 }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <EmailIcon color="primary" sx={{ mr: 2 }} />
                  <Typography variant="body1">
                    {userData.email}
                  </Typography>
                </Box>
              </Grid>
              
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <DashboardIcon color="primary" sx={{ mr: 2 }} />
                  <Box>
                    <Typography variant="body2" color="text.secondary">Niveau d'accès</Typography>
                    <Typography variant="body1" fontWeight="500">{userData.accessLevel}</Typography>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Box>
          
          <Button 
            variant="outlined" 
            startIcon={<SettingsIcon />} 
            sx={{ mt: 1, mb: 3, width: '100%' }}
          >
            Modifier mon profil
          </Button>
        </Box>
      </Card>
    </Container>
  );
};

export default Profile;
