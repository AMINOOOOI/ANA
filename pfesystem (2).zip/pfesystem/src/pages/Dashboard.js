import React from 'react';
import { 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Box, 
  Card, 
  CardContent, 
  CardActions,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
} from '@mui/material';
import { 
  Assignment as AssignmentIcon,
  School as SchoolIcon,
  Person as PersonIcon,
  Description as DescriptionIcon,
  CalendarToday as CalendarTodayIcon
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

// Mock data for the dashboard
const recentPFEs = [
  { id: 1, title: 'Système de gestion de projets de fin d\'études', students: 'Ahmed Alami, Fatima Bennani', department: 'Informatique', date: '2025-06-10' },
  { id: 2, title: 'Application mobile de suivi médical', students: 'Mohammed Tazi', department: 'Génie Logiciel', date: '2025-06-12' },
  { id: 3, title: 'Système IoT pour agriculture intelligente', students: 'Karim El Mansouri, Laila Bensouda', department: 'Informatique', date: '2025-06-15' },
];



const Dashboard = () => {
  const { currentUser, userRole } = useAuth();
  const navigate = useNavigate();

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Paper 
        elevation={0}
        sx={{ 
          p: 3, 
          mb: 4, 
          borderRadius: 3,
          background: 'linear-gradient(135deg, #1e88e5 0%, #0d47a1 100%)',
          color: 'white',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            width: '150px',
            height: '150px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.1)',
            transform: 'translate(50%, -50%)',
          }}
        />
        <Box
          sx={{
            position: 'absolute',
            bottom: 0,
            left: '10%',
            width: '100px',
            height: '100px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.1)',
            transform: 'translate(-50%, 50%)',
          }}
        />
        <Box sx={{ position: 'relative', zIndex: 1 }}>
          <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
            Tableau de bord
          </Typography>
          <Typography variant="subtitle1" sx={{ opacity: 0.9, mb: 1 }}>
            Bienvenue, <Box component="span" sx={{ fontWeight: 'bold' }}>{currentUser?.name}</Box>
          </Typography>
          <Box 
            sx={{ 
              display: 'inline-flex', 
              alignItems: 'center', 
              bgcolor: 'rgba(255, 255, 255, 0.2)', 
              borderRadius: 4, 
              px: 2, 
              py: 0.5,
              mt: 1
            }}
          >
            {userRole === 'admin' ? <PersonIcon sx={{ mr: 1, fontSize: 16 }} /> : 
              userRole === 'library' ? <SchoolIcon sx={{ mr: 1, fontSize: 16 }} /> : 
              <AssignmentIcon sx={{ mr: 1, fontSize: 16 }} />}
            <Typography variant="body2">
              {userRole === 'admin' ? 'Administrateur' : 
                userRole === 'library' ? 'Responsable de bibliothèque' : 'Étudiant'}
            </Typography>
          </Box>
        </Box>
      </Paper>



      <Grid container spacing={3} sx={{ mt: 1 }}>
        {/* Recent PFEs */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }} elevation={3}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              PFEs récents
            </Typography>
            <List>
              {recentPFEs.map((pfe, index) => (
                <React.Fragment key={pfe.id}>
                  <ListItem 
                    button 
                    onClick={() => navigate(`/pfe/${pfe.id}`)}
                    alignItems="flex-start"
                  >
                    <ListItemIcon>
                      <AssignmentIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText
                      primary={pfe.title}
                      secondary={
                        <React.Fragment>
                          <Typography
                            sx={{ display: 'block' }}
                            component="span"
                            variant="body2"
                            color="text.primary"
                          >
                            Étudiants: {pfe.students}
                          </Typography>
                          <Typography
                            component="span"
                            variant="body2"
                          >
                            Département: {pfe.department} • Soutenance: {new Date(pfe.date).toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })}
                          </Typography>
                        </React.Fragment>
                      }
                    />
                  </ListItem>
                  {index < recentPFEs.length - 1 && <Divider variant="inset" component="li" />}
                </React.Fragment>
              ))}
            </List>
            <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
              <Button 
                variant="contained" 
                color="primary" 
                onClick={() => navigate('/pfe')}
              >
                Voir tous les PFEs
              </Button>
            </Box>
          </Paper>
        </Grid>

        {/* Quick Actions */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }} elevation={3}>
            <Typography component="h2" variant="h6" color="primary" gutterBottom>
              Actions rapides
            </Typography>
            
            <Grid container spacing={2}>
              {userRole === 'library' && (
                <Grid item xs={12}>
                  <Card variant="outlined">
                    <CardContent>
                      <Typography variant="h6" component="h3">
                        Soumettre un nouveau PFE
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Ajoutez les informations d'un nouveau projet de fin d'études.
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Button 
                        size="small" 
                        color="primary" 
                        onClick={() => navigate('/pfe/new')}
                      >
                        Commencer
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              )}

              <Grid item xs={12}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography variant="h6" component="h3">
                      Rechercher des PFEs
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Trouvez des projets par titre, formation ou encadrant.
                    </Typography>
                  </CardContent>
                  <CardActions>
                    <Button 
                      size="small" 
                      color="primary"
                      onClick={() => navigate('/pfe?search=true')}
                    >
                      Rechercher
                    </Button>
                  </CardActions>
                </Card>
              </Grid>

              {userRole === 'admin' && (
                <Grid item xs={12}>
                  <Card variant="outlined">
                    <CardContent>
                      <Typography variant="h6" component="h3">
                        Statistiques
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Consultez les statistiques de l'ensemble des projets.
                      </Typography>
                    </CardContent>
                    <CardActions>
                      <Button 
                        size="small" 
                        color="primary"
                        onClick={() => navigate('/statistics')}
                      >
                        Voir les statistiques
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              )}
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Dashboard;
