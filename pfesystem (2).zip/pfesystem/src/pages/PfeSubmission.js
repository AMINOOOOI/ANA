import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Paper,
  Grid,
  TextField,
  MenuItem,
  Button,
  Stepper,
  Step,
  StepLabel,
  Alert,
  InputLabel,
  FormControl,
  Select,
  Chip,
  OutlinedInput,
  Divider
} from '@mui/material';
import { 
  Upload as UploadIcon, 
  NavigateNext as NextIcon, 
  NavigateBefore as PrevIcon,
  Check as CheckIcon 
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

// Mock data for dropdowns
const studyLevels = [
  { value: 'licence', label: 'Licence' },
  { value: 'master', label: 'Master' },
  { value: 'ingenieur', label: 'Cycle d\'ingénieur' },
];

const departments = [
  { value: 'informatique', label: 'Informatique' },
  { value: 'genie_civil', label: 'Génie Civil' },
  { value: 'electronique', label: 'Électronique' },
  { value: 'mecanique', label: 'Mécanique' },
];

const formations = {
  informatique: [
    { value: 'genie_logiciel', label: 'Génie Logiciel' },
    { value: 'securite_informatique', label: 'Sécurité Informatique' },
    { value: 'reseaux', label: 'Réseaux et Télécommunications' },
  ],
  genie_civil: [
    { value: 'batiment', label: 'Bâtiments' },
    { value: 'hydraulique', label: 'Hydraulique' },
    { value: 'transport', label: 'Transport' },
  ],
  electronique: [
    { value: 'systemes_embarques', label: 'Systèmes Embarqués' },
    { value: 'telecommunications', label: 'Télécommunications' },
  ],
  mecanique: [
    { value: 'conception', label: 'Conception Mécanique' },
    { value: 'energetique', label: 'Énergétique' },
  ],
};

const departmentHeads = {
  informatique: 'Dr. Mohammed Benali',
  genie_civil: 'Dr. Fatima Zahra Alaoui',
  electronique: 'Dr. Ahmed Bensouda',
  mecanique: 'Dr. Karim El Mansouri',
};

const PfeSubmission = () => {
  const { userRole } = useAuth();
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  // Form data
  const [formData, setFormData] = useState({
    // Step 1: Education Level
    studyLevel: '',
    
    // Step 2: Department & Formation
    department: '',
    formation: '',
    departmentHead: '',
    
    // Step 3: PFE Details
    students: [],
    currentStudent: { name: '', massarCode: '' },
    supervisor: '',
    juryMembers: '',
    title: '',
    defenseDate: '',
    report: null,
  });
  
  const steps = ['Niveau d\'étude', 'Filière et département', 'Informations du PFE'];
  
  const handleNext = () => {
    let isValid = true;
    setError('');
    
    // Validation for Step 1
    if (activeStep === 0) {
      if (!formData.studyLevel) {
        setError('Veuillez sélectionner un niveau d\'étude.');
        isValid = false;
      }
    }
    
    // Validation for Step 2
    if (activeStep === 1) {
      if (!formData.department || !formData.formation) {
        setError('Veuillez sélectionner un département et une formation.');
        isValid = false;
      }
    }
    
    // Validation for Step 3
    if (activeStep === 2) {
      if (
        formData.students.length === 0 ||
        !formData.supervisor ||
        !formData.juryMembers ||
        !formData.title ||
        !formData.defenseDate
      ) {
        setError('Veuillez remplir tous les champs obligatoires.');
        isValid = false;
      }
    }
    
    if (isValid) {
      setActiveStep((prevStep) => prevStep + 1);
    }
  };
  
  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };
  
  const handleDepartmentChange = (e) => {
    const department = e.target.value;
    setFormData({
      ...formData,
      department,
      formation: '',
      departmentHead: departmentHeads[department] || '',
    });
  };
  
  const handleAddStudent = () => {
    const { name, massarCode } = formData.currentStudent;
    
    if (!name || !massarCode) {
      setError('Veuillez remplir tous les champs pour l\'étudiant.');
      return;
    }
    
    if (formData.students.some(student => student.massarCode === massarCode)) {
      setError('Ce code Massar est déjà utilisé pour un étudiant.');
      return;
    }
    
    setFormData({
      ...formData,
      students: [...formData.students, { name, massarCode }],
      currentStudent: { name: '', massarCode: '' },
    });
    
    setError('');
  };
  
  const handleRemoveStudent = (massarCode) => {
    setFormData({
      ...formData,
      students: formData.students.filter(student => student.massarCode !== massarCode),
    });
  };
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        setError('Veuillez soumettre uniquement des fichiers PDF.');
        return;
      }
      
      if (file.size > 10 * 1024 * 1024) { // 10MB max
        setError('La taille du fichier ne doit pas dépasser 10MB.');
        return;
      }
      
      setFormData({
        ...formData,
        report: file,
      });
      setError('');
    }
  };
  
  const handleSubmit = async () => {
    try {
      // Here we would normally submit the form data to an API
      console.log('Form data to submit:', formData);
      
      // Simulate a successful submission
      setSuccess('PFE soumis avec succès !');
      
      // In a real application, we'd navigate to the PFE details page after submission
      setTimeout(() => {
        navigate('/pfe');
      }, 2000);
    } catch (error) {
      setError('Erreur lors de la soumission du PFE. Veuillez réessayer.');
    }
  };
  
  // Check if user has the right role to access this page
  if (userRole !== 'library' && userRole !== 'admin') {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error">
          Vous n'avez pas les autorisations nécessaires pour accéder à cette page.
        </Alert>
      </Container>
    );
  }
  
  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 8 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 2 }}>
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom align="center">
            Déclaration d'un nouveau PFE
          </Typography>
          <Typography variant="subtitle1" color="text.secondary" align="center">
            Remplissez les informations pour soumettre un projet de fin d'études.
          </Typography>
        </Box>
        
        {/* Stepper */}
        <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ mb: 3 }}>{success}</Alert>}
        
        {/* Step content */}
        <Box sx={{ mb: 4 }}>
          {/* Step 1: Education Level */}
          {activeStep === 0 && (
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <FormControl fullWidth required>
                  <InputLabel id="study-level-label">Niveau d'étude</InputLabel>
                  <Select
                    labelId="study-level-label"
                    id="study-level"
                    value={formData.studyLevel}
                    label="Niveau d'étude"
                    onChange={(e) => setFormData({ ...formData, studyLevel: e.target.value })}
                  >
                    {studyLevels.map((level) => (
                      <MenuItem key={level.value} value={level.value}>
                        {level.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          )}
          
          {/* Step 2: Department & Formation */}
          {activeStep === 1 && (
            <Grid container spacing={3}>
              <Grid item xs={12}>
                <FormControl fullWidth required>
                  <InputLabel id="department-label">Département</InputLabel>
                  <Select
                    labelId="department-label"
                    id="department"
                    value={formData.department}
                    label="Département"
                    onChange={handleDepartmentChange}
                  >
                    {departments.map((dept) => (
                      <MenuItem key={dept.value} value={dept.value}>
                        {dept.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12}>
                <FormControl fullWidth required disabled={!formData.department}>
                  <InputLabel id="formation-label">Formation</InputLabel>
                  <Select
                    labelId="formation-label"
                    id="formation"
                    value={formData.formation}
                    label="Formation"
                    onChange={(e) => setFormData({ ...formData, formation: e.target.value })}
                  >
                    {formData.department && 
                      formations[formData.department].map((formation) => (
                        <MenuItem key={formation.value} value={formation.value}>
                          {formation.label}
                        </MenuItem>
                      ))
                    }
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Chef de département"
                  value={formData.departmentHead}
                  InputProps={{
                    readOnly: true,
                  }}
                  variant="filled"
                />
              </Grid>
            </Grid>
          )}
          
          {/* Step 3: PFE Information */}
          {activeStep === 2 && (
            <>
              <Typography variant="h6" sx={{ mb: 2 }}>Informations des étudiants</Typography>
              
              <Grid container spacing={2} sx={{ mb: 3 }}>
                <Grid item xs={12} sm={5}>
                  <TextField
                    fullWidth
                    label="Nom complet de l'étudiant"
                    value={formData.currentStudent.name}
                    onChange={(e) => setFormData({
                      ...formData,
                      currentStudent: { ...formData.currentStudent, name: e.target.value }
                    })}
                  />
                </Grid>
                <Grid item xs={12} sm={5}>
                  <TextField
                    fullWidth
                    label="Code Massar"
                    value={formData.currentStudent.massarCode}
                    onChange={(e) => setFormData({
                      ...formData,
                      currentStudent: { ...formData.currentStudent, massarCode: e.target.value }
                    })}
                  />
                </Grid>
                <Grid item xs={12} sm={2}>
                  <Button
                    variant="contained"
                    fullWidth
                    onClick={handleAddStudent}
                    sx={{ height: '100%' }}
                  >
                    Ajouter
                  </Button>
                </Grid>
              </Grid>
              
              {formData.students.length > 0 && (
                <Box sx={{ mb: 3, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {formData.students.map((student) => (
                    <Chip
                      key={student.massarCode}
                      label={`${student.name} (${student.massarCode})`}
                      onDelete={() => handleRemoveStudent(student.massarCode)}
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
              )}
              
              <Divider sx={{ my: 3 }} />
              
              <Typography variant="h6" sx={{ mb: 2 }}>Informations du projet</Typography>
              
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    required
                    label="Titre du projet"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    required
                    label="Nom de l'encadrant"
                    value={formData.supervisor}
                    onChange={(e) => setFormData({ ...formData, supervisor: e.target.value })}
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    required
                    label="Membres du jury (séparés par des virgules)"
                    value={formData.juryMembers}
                    onChange={(e) => setFormData({ ...formData, juryMembers: e.target.value })}
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    required
                    label="Date de soutenance"
                    type="date"
                    value={formData.defenseDate}
                    onChange={(e) => setFormData({ ...formData, defenseDate: e.target.value })}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <Button
                    variant="outlined"
                    component="label"
                    startIcon={<UploadIcon />}
                    fullWidth
                    sx={{ height: '56px' }}
                  >
                    {formData.report ? formData.report.name : 'Ajouter le rapport (PDF)'}
                    <input
                      type="file"
                      accept=".pdf"
                      hidden
                      onChange={handleFileChange}
                    />
                  </Button>
                </Grid>
              </Grid>
            </>
          )}
          
          {/* Final Step: Submission Summary */}
          {activeStep === 3 && (
            <Box>
              <Alert severity="info" sx={{ mb: 3 }}>
                Veuillez vérifier les informations avant de soumettre.
              </Alert>
              
              <Typography variant="h6" gutterBottom>
                Résumé de la soumission
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Niveau d'étude:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>
                    {studyLevels.find(level => level.value === formData.studyLevel)?.label}
                  </Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Département:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>
                    {departments.find(dept => dept.value === formData.department)?.label}
                  </Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Formation:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>
                    {formData.department && formations[formData.department].find(f => f.value === formData.formation)?.label}
                  </Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Chef de département:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>{formData.departmentHead}</Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Étudiants:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Box>
                    {formData.students.map((student) => (
                      <Typography key={student.massarCode}>
                        {student.name} ({student.massarCode})
                      </Typography>
                    ))}
                  </Box>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Titre du projet:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>{formData.title}</Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Encadrant:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>{formData.supervisor}</Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Membres du jury:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>{formData.juryMembers}</Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Date de soutenance:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>
                    {formData.defenseDate && new Date(formData.defenseDate).toLocaleDateString('fr-FR')}
                  </Typography>
                </Grid>
                
                <Grid item xs={4}>
                  <Typography variant="subtitle2">Rapport:</Typography>
                </Grid>
                <Grid item xs={8}>
                  <Typography>{formData.report ? formData.report.name : 'Non ajouté'}</Typography>
                </Grid>
              </Grid>
            </Box>
          )}
        </Box>
        
        {/* Navigation buttons */}
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
            startIcon={<PrevIcon />}
          >
            Précédent
          </Button>
          
          {activeStep === steps.length ? (
            <Button
              variant="contained"
              color="success"
              onClick={handleSubmit}
              endIcon={<CheckIcon />}
            >
              Soumettre
            </Button>
          ) : (
            <Button
              variant="contained"
              onClick={handleNext}
              endIcon={<NextIcon />}
            >
              {activeStep === steps.length - 1 ? 'Vérifier' : 'Suivant'}
            </Button>
          )}
        </Box>
      </Paper>
    </Container>
  );
};

export default PfeSubmission;
