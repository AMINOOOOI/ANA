import React from 'react';
import {
  Container,
  Typography,
  Box,
  Paper,
  Grid,
  Card,
  CardContent,
  useTheme
} from '@mui/material';
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';

// Données fictives pour les statistiques des PFE par département
const departmentData = [
  { name: 'Informatique', pfeCount: 48, fill: '#1e88e5' },
  { name: 'Génie Civil', pfeCount: 32, fill: '#26a69a' },
  { name: 'Électronique', pfeCount: 27, fill: '#ff8f00' },
  { name: 'Mécanique', pfeCount: 21, fill: '#7b1fa2' },
  { name: 'Télécommunications', pfeCount: 15, fill: '#f44336' },
];

// Données pour la distribution par formation
const formationData = [
  { name: 'Licence', value: 45, fill: '#1e88e5' },
  { name: 'Master', value: 58, fill: '#26a69a' },
  { name: 'Cycle d\'ingénierie', value: 35, fill: '#ff8f00' },
];

// Calculer le nombre total de PFEs
const totalPFEs = departmentData.reduce((sum, dept) => sum + dept.pfeCount, 0);

const Statistics = () => {
  const theme = useTheme();

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Paper 
        elevation={0}
        sx={{ 
          p: 3, 
          mb: 4, 
          borderRadius: 3,
          background: 'linear-gradient(135deg, #7b1fa2 0%, #3f51b5 100%)',
          color: 'white',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            width: '150px',
            height: '150px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.1)',
            transform: 'translate(50%, -50%)',
          }}
        />
        <Box sx={{ position: 'relative', zIndex: 1 }}>
          <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
            Statistiques des PFEs
          </Typography>
          <Typography variant="subtitle1" sx={{ opacity: 0.9 }}>
            Total des PFEs : <strong>{totalPFEs}</strong>
          </Typography>
        </Box>
      </Paper>

      {/* Statistiques */}
      <Grid container spacing={3}>
        {/* PFEs par département */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%', borderRadius: 2, boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom fontWeight="medium">
                Distribution des PFEs par département
              </Typography>
              <Box sx={{ height: 350 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={departmentData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 50,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-45} textAnchor="end" height={60} />
                    <YAxis />
                    <Tooltip formatter={(value) => [`${value} PFEs`, 'Nombre']} />
                    <Legend />
                    <Bar dataKey="pfeCount" name="Nombre de PFEs" radius={[5, 5, 0, 0]}>
                      {departmentData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* PFEs par formation */}
        <Grid item xs={12} md={6}>
          <Card sx={{ height: '100%', borderRadius: 2, boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom fontWeight="medium">
                Distribution des PFEs par formation
              </Typography>
              <Box sx={{ height: 350 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={formationData}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value} PFEs`}
                    >
                      {formationData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [`${value} PFEs`, 'Nombre']} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Résumé Total */}
        <Grid item xs={12}>
          <Card sx={{ borderRadius: 2, boxShadow: '0 4px 20px rgba(0,0,0,0.05)' }}>
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom fontWeight="medium">
                    Résumé des PFEs
                  </Typography>
                </Grid>
                
                {/* Total PFEs */}
                <Grid item xs={12} sm={4}>
                  <Box 
                    sx={{ 
                      p: 3, 
                      borderRadius: 2, 
                      bgcolor: theme.palette.primary.main,
                      color: 'white',
                      textAlign: 'center'
                    }}
                  >
                    <Typography variant="h4" fontWeight="bold">
                      {totalPFEs}
                    </Typography>
                    <Typography variant="body1">
                      Total des PFEs
                    </Typography>
                  </Box>
                </Grid>
                
                {/* Top Département */}
                <Grid item xs={12} sm={4}>
                  <Box 
                    sx={{ 
                      p: 3, 
                      borderRadius: 2, 
                      bgcolor: '#26a69a',
                      color: 'white',
                      textAlign: 'center'
                    }}
                  >
                    <Typography variant="h4" fontWeight="bold">
                      {departmentData[0].name}
                    </Typography>
                    <Typography variant="body1">
                      Département avec le plus de PFEs ({departmentData[0].pfeCount})
                    </Typography>
                  </Box>
                </Grid>
                
                {/* Top Formation */}
                <Grid item xs={12} sm={4}>
                  <Box 
                    sx={{ 
                      p: 3, 
                      borderRadius: 2, 
                      bgcolor: '#ff8f00',
                      color: 'white',
                      textAlign: 'center'
                    }}
                  >
                    <Typography variant="h4" fontWeight="bold">
                      {formationData.sort((a, b) => b.value - a.value)[0].name}
                    </Typography>
                    <Typography variant="body1">
                      Formation avec le plus de PFEs ({formationData.sort((a, b) => b.value - a.value)[0].value})
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Statistics;
