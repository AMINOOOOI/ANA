import React, { useState } from 'react';
import {
  Container, Typography, Box, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, TablePagination, IconButton, Button, TextField, Stack,
  Avatar, Chip, Dialog, DialogTitle, DialogContent, DialogActions, MenuItem,
  Snackbar, Alert, FormControl, InputLabel, Select
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Search as SearchIcon,
  PersonAdd as PersonAddIcon
} from '@mui/icons-material';

// Données fictives pour les utilisateurs
const mockUsers = [
  { id: 1, name: 'Admin User', email: 'admin@example.com', role: 'admin', department: 'Administration', active: true },
  { id: 2, name: 'Library Manager', email: 'library@example.com', role: 'library', department: 'Bibliothèque', active: true },
  { id: 3, name: 'Student User', email: 'student@example.com', role: 'student', department: 'Informatique', active: true },
  { id: 4, name: 'Sofia Benali', email: 'sofia@example.com', role: 'student', department: 'Génie Civil', active: true },
  { id: 5, name: 'Karim Tazi', email: 'karim@example.com', role: 'student', department: 'Électronique', active: false },
  { id: 6, name: 'Nadia Chaoui', email: 'nadia@example.com', role: 'library', department: 'Bibliothèque', active: true },
  { id: 7, name: 'Youssef Alami', email: 'youssef@example.com', role: 'student', department: 'Informatique', active: true },
  { id: 8, name: 'Fatima Bennani', email: 'fatima@example.com', role: 'student', department: 'Mécanique', active: true },
];

const UserManagement = () => {
  // États pour la gestion des utilisateurs
  const [users, setUsers] = useState(mockUsers);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [searchTerm, setSearchTerm] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  
  // États pour le formulaire d'édition/création
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'student',
    department: '',
    active: true
  });

  // Gestion de la pagination
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Filtrage des utilisateurs
  const filteredUsers = users.filter((user) =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Ouverture du dialogue pour l'édition
  const handleEditUser = (user) => {
    setCurrentUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department
    });
    setOpenDialog(true);
  };

  // Ouverture du dialogue pour la création
  const handleAddUser = () => {
    setCurrentUser(null);
    setFormData({
      name: '',
      email: '',
      role: 'student',
      department: ''
    });
    setOpenDialog(true);
  };

  // Gestion des changements de formulaire
  const handleFormChange = (e) => {
    const { name, value, checked } = e.target;
    setFormData({
      ...formData,
      [name]: name === 'active' ? checked : value,
    });
  };

  // Soumission du formulaire
  const handleSubmit = () => {
    if (currentUser) {
      // Édition d'un utilisateur existant
      setUsers(users.map(user => 
        user.id === currentUser.id ? { ...user, ...formData, active: user.active } : user
      ));
      setSnackbar({ open: true, message: 'Utilisateur modifié avec succès', severity: 'success' });
    } else {
      // Création d'un nouvel utilisateur
      const newUser = {
        id: users.length + 1,
        ...formData,
        active: true // Valeur par défaut maintenue dans les données mais pas dans l'interface
      };
      setUsers([...users, newUser]);
      setSnackbar({ open: true, message: 'Utilisateur créé avec succès', severity: 'success' });
    }
    setOpenDialog(false);
  };

  // Suppression d'un utilisateur
  const handleDeleteUser = (userId) => {
    setUsers(users.filter(user => user.id !== userId));
    setSnackbar({ open: true, message: 'Utilisateur supprimé avec succès', severity: 'info' });
  };

  // Fermeture du snackbar
  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };


  // Affichage du rôle avec un style approprié
  const getRoleChip = (role) => {
    let color = 'default';
    let label = 'Inconnu';
    
    switch(role) {
      case 'admin':
        color = 'error';
        label = 'Admin';
        break;
      case 'library':
        color = 'primary';
        label = 'Bibliothécaire';
        break;
      case 'student':
        color = 'info';
        label = 'Étudiant';
        break;
      default:
        break;
    }
    
    return <Chip label={label} color={color} size="small" />;
  };

  // Génère les initiales pour l'avatar
  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase();
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Paper 
        elevation={0}
        sx={{ 
          p: 3, 
          mb: 4, 
          borderRadius: 3,
          background: 'linear-gradient(135deg, #4527a0 0%, #8e24aa 100%)',
          color: 'white',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            width: '150px',
            height: '150px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.1)',
            transform: 'translate(50%, -50%)',
          }}
        />
        <Box sx={{ position: 'relative', zIndex: 1 }}>
          <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
            Gestion des utilisateurs
          </Typography>
          <Typography variant="subtitle1" sx={{ opacity: 0.9 }}>
            Administrez tous les utilisateurs du système
          </Typography>
        </Box>
      </Paper>

      {/* Barre d'actions */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <TextField
          placeholder="Rechercher un utilisateur..."
          size="small"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          sx={{ width: '40%' }}
          InputProps={{
            startAdornment: <SearchIcon color="action" sx={{ mr: 1 }} />,
          }}
        />
        <Button
          variant="contained"
          color="primary"
          startIcon={<PersonAddIcon />}
          onClick={handleAddUser}
        >
          Ajouter un utilisateur
        </Button>
      </Box>
      
      {/* Tableau des utilisateurs */}
      <Paper sx={{ width: '100%', mb: 3, borderRadius: 2, overflow: 'hidden' }}>
        <TableContainer>
          <Table>
            <TableHead sx={{ bgcolor: 'rgba(0, 0, 0, 0.02)' }}>
              <TableRow>
                <TableCell>Utilisateur</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>Rôle</TableCell>
                <TableCell>Département</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredUsers
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((user) => (
                  <TableRow key={user.id} hover>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Avatar 
                          sx={{ 
                            bgcolor: user.role === 'admin' ? '#e53935' : 
                                    user.role === 'library' ? '#1976d2' : '#26a69a',
                            width: 36, 
                            height: 36,
                            mr: 2
                          }}
                        >
                          {getInitials(user.name)}
                        </Avatar>
                        <Typography variant="body2">{user.name}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{getRoleChip(user.role)}</TableCell>
                    <TableCell>{user.department}</TableCell>
                    <TableCell align="right">
                      <IconButton 
                        size="small" 
                        color="primary" 
                        onClick={() => handleEditUser(user)}
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                      <IconButton 
                        size="small" 
                        color="error" 
                        onClick={() => handleDeleteUser(user.id)}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              }
              {filteredUsers.length === 0 && (
                <TableRow style={{ height: 53 }}>
                  <TableCell colSpan={5} align="center">
                    Aucun utilisateur trouvé.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredUsers.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          labelRowsPerPage="Par page"
          labelDisplayedRows={({ from, to, count }) => 
            `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
          }
        />
      </Paper>

      {/* Dialogue d'édition/création */}
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          {currentUser ? 'Modifier utilisateur' : 'Ajouter un nouvel utilisateur'}
        </DialogTitle>
        <DialogContent>
          <Box component="form" sx={{ mt: 1 }}>
            <TextField
              margin="normal"
              required
              fullWidth
              label="Nom complet"
              name="name"
              value={formData.name}
              onChange={handleFormChange}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              label="Email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleFormChange}
            />
            <FormControl fullWidth margin="normal">
              <InputLabel>Rôle</InputLabel>
              <Select
                name="role"
                value={formData.role}
                label="Rôle"
                onChange={handleFormChange}
              >
                <MenuItem value="student">Étudiant</MenuItem>
                <MenuItem value="library">Bibliothécaire</MenuItem>
                <MenuItem value="admin">Administrateur</MenuItem>
              </Select>
            </FormControl>
            <TextField
              margin="normal"
              required
              fullWidth
              label="Département"
              name="department"
              value={formData.department}
              onChange={handleFormChange}
            />
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button onClick={() => setOpenDialog(false)} color="inherit">
            Annuler
          </Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained" 
            startIcon={currentUser ? <EditIcon /> : <AddIcon />}
          >
            {currentUser ? 'Mettre à jour' : 'Ajouter'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Notification */}
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default UserManagement;
