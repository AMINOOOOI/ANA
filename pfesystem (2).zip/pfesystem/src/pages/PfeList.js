import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  IconButton,
  TextField,
  InputAdornment,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Divider,
  Card,
  CardContent
} from '@mui/material';
import {
  Search as SearchIcon,
  Visibility as VisibilityIcon,
  FilterList as FilterListIcon,
  Clear as ClearIcon
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';

// Données réalistes pour la liste des PFEs basées sur les départements et formations réels
const mockPFEs = [
  {
    id: 1,
    title: 'Développement d\'une plateforme d\'analyse prédictive pour l\'optimisation des ressources dans les centres de données',
    student: 'Omar Bensouda, Amina El Mansouri',
    supervisor: 'Dr. Mohammed Tazi',
    department: 'Informatique',
    formation: 'Master Artificial Intelligence & Digital Computing',
    submitDate: '2025-05-01',
    domain: 'Intelligence Artificielle'
  },
  {
    id: 2,
    title: 'Conception et implémentation d\'un système embarqué pour le monitoring de véhicules électriques',
    student: 'Youssef El Kaddioui, Fatima Zohra Mansour',
    supervisor: 'Dr. Rachid Alaoui',
    department: 'Génie Électrique',
    formation: 'Ingénierie Électronique et Télécommunication',
    submitDate: '2025-05-03',
    domain: 'Systèmes Embarqués'
  },
  {
    id: 3,
    title: 'Système IoT de surveillance environnementale pour l\'agriculture de précision',
    student: 'Sara Moussaid, Karim Berrada',
    supervisor: 'Dr. Hamid Naciri',
    department: 'Informatique',
    formation: 'Ingénierie Logicielle et Intégration des Systèmes Informatiques (ILISI)',
    submitDate: '2025-05-05',
    domain: 'IoT'
  },
  {
    id: 4,
    title: 'Optimisation des processus de fabrication industrielle par simulation numérique',
    student: 'Mehdi Benjelloun',
    supervisor: 'Dr. Noureddine El Ouafi',
    department: 'Génie Mécanique',
    formation: 'Cycle ingénieur Productique / Mécatronique',
    submitDate: '2025-05-06',
    domain: 'Productique'
  },
  {
    id: 5,
    title: 'Caractérisation et modélisation des matériaux composites pour applications industrielles',
    student: 'Mohammed Erradi, Zineb Lahlou',
    supervisor: 'Dr. Nadia Tazi',
    department: 'Physique',
    formation: 'Master Ingénierie des Matériaux',
    submitDate: '2025-05-08',
    domain: 'Matériaux'
  },
  {
    id: 6,
    title: 'Application des méthodes d\'analyse numérique avancée aux équations de diffusion non linéaires',
    student: 'Leila Benziane',
    supervisor: 'Dr. Khalid Lahrouz',
    department: 'Mathématiques',
    formation: 'Master Analyse Mathématique Avancée',
    submitDate: '2025-05-10',
    domain: 'Analyse Numérique'
  },
  {
    id: 7,
    title: 'Évaluation des méthodes de dépollution des eaux usées par bioremédiation',
    student: 'Hajar Bourass, Samir Chaoui',
    supervisor: 'Dr. Samira El Mokhtar',
    department: 'Chimie et Environnement',
    formation: 'Licence Protection de l\'Environnement',
    submitDate: '2025-05-12',
    domain: 'Environnement'
  },
  {
    id: 8,
    title: 'Développement d\'algorithmes de Deep Learning pour la détection des pathologies cérébrales',
    student: 'Salma Kabbaj, Nabil Benkirane',
    supervisor: 'Dr. Mourad Fadili',
    department: 'Informatique',
    formation: 'Master Artificial Intelligence & Digital Computing',
    submitDate: '2025-05-14',
    domain: 'Deep Learning / Médical'
  },
  {
    id: 9,
    title: 'Étude et optimisation des cellules photovoltaïques à base de pérovskites',
    student: 'Amine Lahrichi',
    supervisor: 'Dr. Latifa Zekri',
    department: 'Physique',
    formation: 'Cycle ingénieur Génie Physique',
    submitDate: '2025-05-16',
    domain: 'Énergie'
  },
  {
    id: 10,
    title: 'Conception d\'un système mécatronique pour la réhabilitation motrice',
    student: 'Ismail Benjelloun, Houda Bennani',
    supervisor: 'Dr. Jamal Rifai',
    department: 'Génie Mécanique',
    formation: 'Cycle ingénieur Mécatronique',
    submitDate: '2025-05-18',
    domain: 'Mécatronique / Biomédical'
  },
  {
    id: 11,
    title: 'Développement de biosenseurs pour la détection précoce de biomarqueurs du cancer',
    student: 'Meryem Alaoui',
    supervisor: 'Dr. Hafida Merzouki',
    department: 'Sciences de la Vie',
    formation: 'Master Sciences & Techniques en Neurosciences & Biotechnologie',
    submitDate: '2025-05-20',
    domain: 'Biotechnologie'
  },
  {
    id: 12,
    title: 'Cartographie SIG et analyse spatiale des risques d\'inondation dans la région de Marrakech',
    student: 'Kamal Idrissi, Loubna Benslimane',
    supervisor: 'Dr. Abdelhak Boutaleb',
    department: 'Sciences de la Terre',
    formation: 'Master Géomatique Environnementale',
    submitDate: '2025-05-22',
    domain: 'Géomatique'
  },
  {
    id: 13,
    title: 'Implémentation d\'un framework réactif pour le développement d\'applications mobiles multiplateformes',
    student: 'Yasmine Kadiri',
    supervisor: 'Dr. Brahim Nouri',
    department: 'Informatique',
    formation: 'Cycle ingénieur ILISI',
    submitDate: '2025-05-24',
    domain: 'Mobile Development'
  },
  {
    id: 14,
    title: 'Analyse et contrôle qualité des matières premières pharmaceutiques par spectroscopie',
    student: 'Achraf Belkadi, Salma Ouazzani',
    supervisor: 'Dr. Naima Benabdellah',
    department: 'Chimie et Environnement',
    formation: 'Master Techniques d\'Analyse & Contrôle Qualité Industriel',
    submitDate: '2025-05-26',
    domain: 'Contrôle Qualité'
  },
  {
    id: 15,
    title: 'Modélisation mathématique des phénomènes de propagation d\'épidémies',
    student: 'Reda Bennani',
    supervisor: 'Dr. Farida Alami',
    department: 'Mathématiques',
    formation: 'Master Génie Mathématique & Applications',
    submitDate: '2025-05-28',
    domain: 'Modélisation'
  },
  {
    id: 16,
    title: 'Solution de cyber-sécurité pour PME',
    student: 'Omar Idrissi, Fatima Zahra Bennani',
    supervisor: 'Dr. Youssef Chraibi',
    department: 'Informatique',
    formation: 'Cycle ingénieur ILISI',
    submitDate: '2025-05-15',
    domain: 'Sécurité Informatique'
  },
];

// Options pour les filtres
const departmentOptions = [
  'Tous', 
  'Informatique', 
  'Génie Électrique',
  'Génie Mécanique',
  'Physique',
  'Mathématiques',
  'Chimie et Environnement',
  'Sciences de la Vie',
  'Sciences de la Terre'
];

const domainOptions = [
  'Tous', 
  'Intelligence Artificielle', 
  'Deep Learning / Médical',
  'Mobile Development',
  'IoT',
  'Systèmes Embarqués',
  'Productique',
  'Mécatronique / Biomédical',
  'Matériaux',
  'Énergie',
  'Analyse Numérique',
  'Modélisation',
  'Environnement',
  'Biotechnologie',
  'Géomatique',
  'Contrôle Qualité',
  'Sécurité Informatique'
];

const PfeList = () => {
  const navigate = useNavigate();
  const { userRole } = useAuth();
  
  // États pour la pagination et le filtrage
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [searchTerm, setSearchTerm] = useState('');
  const [department, setDepartment] = useState('Tous');
  const [domain, setDomain] = useState('Tous');
  const [showFilters, setShowFilters] = useState(false);

  // Statut des PFE supprimé

  // Gestion des changements de pagination
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Filtrage des PFEs
  const filteredPFEs = mockPFEs.filter(pfe => {
    const matchesSearch = searchTerm === '' ||
      pfe.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pfe.student.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pfe.supervisor.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = department === 'Tous' || pfe.department === department;
    const matchesDomain = domain === 'Tous' || pfe.domain === domain;
    
    return matchesSearch && matchesDepartment && matchesDomain;
  });

  // Reset des filtres
  const handleResetFilters = () => {
    setSearchTerm('');
    setDepartment('Tous');
    setDomain('Tous');
  };

  // Calcul pour la pagination
  const emptyRows = page > 0
    ? Math.max(0, (1 + page) * rowsPerPage - filteredPFEs.length)
    : 0;

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Paper 
        elevation={0}
        sx={{ 
          p: 3, 
          mb: 4, 
          borderRadius: 3,
          background: 'linear-gradient(135deg, #26a69a 0%, #69f0ae 100%)',
          color: 'white',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            right: 0,
            width: '150px',
            height: '150px',
            borderRadius: '50%',
            background: 'rgba(255, 255, 255, 0.1)',
            transform: 'translate(50%, -50%)',
          }}
        />
        <Box sx={{ position: 'relative', zIndex: 1 }}>
          <Typography variant="h4" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
            Liste des PFE
          </Typography>
          <Typography variant="subtitle1" sx={{ opacity: 0.9 }}>
            Consultez et gérez tous les projets de fin d'études
          </Typography>
        </Box>
      </Paper>
      
      {/* Recherche et filtres */}
      <Card sx={{ mb: 3, borderRadius: 2, boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <TextField
              placeholder="Rechercher un PFE..."
              variant="outlined"
              size="small"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              sx={{ width: { xs: '100%', sm: '50%', md: '40%' } }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon color="action" />
                  </InputAdornment>
                ),
                endAdornment: searchTerm && (
                  <InputAdornment position="end">
                    <IconButton size="small" onClick={() => setSearchTerm('')}>
                      <ClearIcon fontSize="small" />
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />
            <Button
              variant="outlined"
              startIcon={<FilterListIcon />}
              onClick={() => setShowFilters(!showFilters)}
              size="small"
            >
              Filtres
            </Button>
          </Box>
          
          {showFilters && (
            <Box sx={{ mt: 2 }}>
              <Divider sx={{ my: 2 }} />
              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} md={3}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Département</InputLabel>
                    <Select
                      value={department}
                      onChange={(e) => setDepartment(e.target.value)}
                      label="Département"
                    >
                      {departmentOptions.map(option => (
                        <MenuItem key={option} value={option}>{option}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} md={3}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Domaine</InputLabel>
                    <Select
                      value={domain}
                      onChange={(e) => setDomain(e.target.value)}
                      label="Domaine"
                    >
                      {domainOptions.map(option => (
                        <MenuItem key={option} value={option}>{option}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={3}>
                  <Button 
                    variant="text" 
                    color="primary" 
                    onClick={handleResetFilters}
                    fullWidth
                  >
                    Réinitialiser
                  </Button>
                </Grid>
              </Grid>
            </Box>
          )}
        </CardContent>
      </Card>
      
      {/* Tableau des PFEs */}
      <Paper sx={{ borderRadius: 2, boxShadow: '0 2px 8px rgba(0,0,0,0.05)', mb: 3 }}>
        <TableContainer>
          <Table sx={{ minWidth: 650 }}>
            <TableHead sx={{ bgcolor: 'rgba(0, 0, 0, 0.02)' }}>
              <TableRow>
                <TableCell sx={{ fontWeight: 'bold' }}>Titre</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Étudiant(s)</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Encadrant</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Département</TableCell>
                <TableCell sx={{ fontWeight: 'bold' }}>Date</TableCell>
                <TableCell align="right" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredPFEs
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((pfe) => (
                  <TableRow key={pfe.id} hover>
                    <TableCell component="th" scope="row" sx={{ maxWidth: 250 }}>
                      <Typography noWrap title={pfe.title}>
                        {pfe.title}
                      </Typography>
                    </TableCell>
                    <TableCell>{pfe.student}</TableCell>
                    <TableCell>{pfe.supervisor}</TableCell>
                    <TableCell>{pfe.department}</TableCell>
                    <TableCell>{new Date(pfe.submitDate).toLocaleDateString()}</TableCell>
                    <TableCell align="right">
                      <IconButton
                        size="small"
                        color="primary"
                        onClick={() => navigate(`/pfe/${pfe.id}`)}
                        title="Voir détails"
                      >
                        <VisibilityIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              }
              
              {emptyRows > 0 && (
                <TableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={7} />
                </TableRow>
              )}
              
              {filteredPFEs.length === 0 && (
                <TableRow style={{ height: 53 }}>
                  <TableCell colSpan={7} align="center">
                    <Typography variant="body2" color="textSecondary">
                      Aucun PFE trouvé avec les critères de recherche actuels.
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        {/* Pagination */}
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredPFEs.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          labelRowsPerPage="Lignes par page:"
          labelDisplayedRows={({ from, to, count }) =>
            `${from}-${to} sur ${count !== -1 ? count : `plus de ${to}`}`
          }
        />
      </Paper>
      
      {/* Actions */}
      {userRole === 'library' && (
        <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => navigate('/pfe/new')}
          >
            Ajouter un nouveau PFE
          </Button>
        </Box>
      )}
    </Container>
  );
};

export default PfeList;
